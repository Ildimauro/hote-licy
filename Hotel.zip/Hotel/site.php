<!DOCTYPE html>
<html lang="pt">
    <head>
		<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="shortcut icon" href="pics/BG.jpg" type="image/x-icon"> 
        <title>Hotel - Criar conta</title>
        <meta name="description" content="Login" />
        <meta name="keywords" content="Login" />
        <meta name="author" content="Hildo Domingos João" />
        
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="bootstrap/css/theme.css" rel="stylesheet">
	<link href="bootstrap/manjolo.css" rel="stylesheet">
    <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>
        <script src="js/modernizr.custom.63321.js"></script>
		
</head>
<body role="image" background="pics/frontal.JPG">
        <div class="col-xs-12  col-lg-4 col-lg-offset-4 col-md-4 col-md-offset-4  col-sm-6 col-sm-offset-3" >
			<br>
			<section class="main"> 
        <form action="Novo-Usuario.php" method="post"><br>
				 	<div class="panel panel-table">
                     <H3>
           <p style="text-align: center;"> CRIAR CONTA </P>
            </H3>
				 		<p class="clearfix">	
							<div  class="panel-primary panel-heading text-center" ><H2 class="panel-title">HOTEL LICY/SOYO</H2>
						</p>

					</div>
					<div class="panel-body"> 
					<div align="center">
					 <p class="clearfix">
                        <!--
						<img src="pics/frontal.JPG" width="350" class="img-responsive" id="frontal.JPG" alt="responsive image">
					 -->
                    </p>
					</div>
					<p class="clearfix" style="color: red">
					<?php
                        if(isset($_SESSION['loginErro'])){
                            echo $_SESSION['loginErro'];
                            unset($_SESSION['loginErro']);
                        }
                    ?>
                   
                    </p>
                    <div align="center">
                    <h3><b>CADASTRAR</b></h3>
                    <b>Nome Usuário</b>
            <br>
            <input type="text" name="idUsuario" required><br>    
            <b>Nome Completo</b>
            <br>
           </Img><input type="text" name="nome" required><br>
            
           <b> Cria a sua senha</b>
            <br>
            <input type="password" name="senha" required>
            <br>
            <br>
            <b>Estado</b>
            <br>
            <select type="text" name="estado">
            <option value=""> Seleciona Estado</option>   
            <option value="Activo"> Activo </option>
            </select> 
            <br>
            <br>
            <b>Escolhe a sua Categoria</b>
            <br>
            <select type="number" name="idNivelAcesso">
            <option value=""> Seleciona Categoria</option>
             <option value="2">Cliente </option>
            
            
            </select><br>
           <b> Data de cadastro</b>
            <br>
            <input type="date"  name="dataCadastro" required><br>
            <b>Até </b>
            <br>
            <input type="date" name="dataModificacao" required><br>
            <br>

            <button>CADASTRAR</button>
            </div>
         </form>
         <br>
         <form action="index.php" method="post">
         <div align="center"><button>Iniciar sessão</button></div>
        </form>
        </section>
			</div>
			</div>
			</div>
        </div>
    </div>
    
</body>
</html>




