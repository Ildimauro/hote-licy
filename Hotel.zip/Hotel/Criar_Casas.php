 <?php
	include_once("principal.php");
?>
<?php
				if(isset($_SESSION['mensagem'])){
					echo $_SESSION['mensagem'];
					unset($_SESSION['mensagem']);
				}
			?>
			
<div class="container-fluid">
<div class="row-fluid">
<div class="col col-lg-H col-md-H col-sm-H haggy">
	
    <div class="panel panel-default panel-table">
        <div class="panel-heading" >
			   
			<p>	              	
	            <div class="divH"><label>Novo Cómodo</label></div>  
	        </p> 
		</div>
		<div class="panel-body">
          <form class="form-horizontal" name="Casa" method="POST" >
   
		  		
			<div class="col-sm-12">
			  <div class="form-group">
				
				<div class="col-sm-4">
				Tipo de Cómodo:
				 
					<input type="text" class="input-sm form-control"  name="Tipo" required="">
				</div>
				<div class="col-sm-4">
				Número Quartos:
				  	<input type="number" class="input-sm form-control" min="1" max="3" name="Quartos" required="">
				</div>
			  	<div class="col-sm-4">
				Área dos Quartos :
					<input type="number" class="input-sm form-control" name="area" maxlength="2" placeholder="m2" >
				  
				</div>
				
			  </div>
			</div>
			<div class="col-sm-12">
			  <div class="form-group">
				<div class="col-sm-4">
				Capacidade:
					<input type="number" class="input-sm form-control" min="1" max="5" name="camas" required="">
				  
				</div>
				<div class="col-sm-4">
					Preço:
					  <input type="text" class="input-sm form-control" name="Preco" maxlength="8" placeholder="AOA / NOITE" required="">
				</div>
				<div class="col-sm-4">
				Estado:
				  <select class="input sm form-control" name="Estado" >
				  		<option value="">Selecione aqui</option>
					  	<option value="Disponivel">Disponivel</option>
					  	<option value="Bloqueado">Bloqueado</option>
					  	
					</select>
				</div>
			  </div>
			</div>
			
         
				<div class="col-sm-6 col col-xs-6 text-left">
				  <button type='button' onclick="Voltar()" class='btn  btn-info'><span class="glyphicon glyphicon-remove"></span>Voltar</button>
				</div>
				<div class="col-sm-6 col col-xs-6 text-right"> 
				  <button type="submit" name="Casa" class="btn btn-success"><span class="glyphicon glyphicon-floppy-disk"></span> Gravar</button>
				</div>
				</form>

</div>
</div>
</div>
</div>

    
    <?php 

if(isset ($_POST['Casa'])){
    
    
    $Tipo = $_POST['Tipo'];
    $Quartos = $_POST['Quartos'];
    $area_quartos = $_POST['area'];
    $camas = $_POST['camas'];
    $Preco = $_POST['Preco'];
    $Estado = $_POST['Estado'];
    
				//Inserindo os dados do formulario usercadastrar na tabela usuarios
				 $inserir = mysqli_query($conectar,"INSERT INTO `alojamento`(`Tipo`, `Quartos`, `area_quartos`, `camas`, `Preco`, `Estado`) VALUES ('$Tipo','$Quartos','$area_quartos','$camas', '$Preco','$Estado')");
				
				 
                
				if ($inserir) 
					/*$inserir1 = mysqli_query($conectar,"INSERT INTO tabela_usuarios (idUsuario, nome,senha, estado, idNivelAcesso , dataCadastro) VALUES ('$email', '$nome $apelido', '$senha', 'Activo', '2', NOW())");
					if ($inserir1)*/{
					$_SESSION['mensagem'] = "
													
														<div class='alert alert-success' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															Alojamento criado com sucesso!.
														</div>
												   	";
					//Manda o usuario para a tela de login
					header("Location: Casas.php");
				}else{
					$_SESSION['mensagem'] = "
													
														<div class='alert alert-danger' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															
															Error: ".mysqli_error($conectar)."
														</div> 
												   	";
					header("Location: Criar_Casas.php");
				}
						
	}


?>
    
<?php
	include_once("rodape.php");
?>