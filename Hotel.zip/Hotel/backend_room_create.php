<?php
require_once '_db.php';

$stmt = $db->prepare("INSERT INTO rooms (name, capacity, Preco, status) VALUES (:name, :capacity, :Preco, 'Disponivel')");
$stmt->bindParam(':Nome do Cómodo', $_POST['name']);
$stmt->bindParam(':Capacidade', $_POST['capacity']);
$stmt->bindParam(':Preco', $_POST['Preco']);
$stmt->execute();

class Result {}

$response = new Result();
$response->result = 'OK';
$response->message = 'Criado com o id: '.$db->lastInsertId();
$response->id = $db->lastInsertId();

header('Content-Type: application/json');
echo json_encode($response);

?>
