<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Edit Event</title>
        <link href="bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet">
    	<link type="text/css" rel="stylesheet" href="media/layout.css" />    
        <script src="js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    </head>
    <body>
        <?php
            // check the input
            is_numeric($_GET['id']) or die("Endereço Inválido");
            
            require_once '_db.php';
            
            $stmt = $db->prepare('SELECT * FROM reservations WHERE id = :id');
            $stmt->bindParam(':id', $_GET['id']);
            $stmt->execute();
            $reservation = $stmt->fetch();
            
            $rooms = $db->query('SELECT * FROM rooms');
        ?>
        <form id="f" action="backend_update.php" style="padding:20px;">
            <input type="hidden" name="id" value="<?php print $_GET['id'] ?>" />
            <div class="modal-header">
            <h1>Editar Reserva</h1>
            </div>
                               
                   
                        <table class="table">
                            <tr>
                                <td>Empresa</td>
                                <td><input type="text" id="empresa" class="input-sm form-control" maxlength="45" minlength="2" style="width: 100%;" name="empresa" value="<?php print $reservation['empresa'] ?>" />
                                </td>
                            </tr>
                            <tr>
                                <td>Nome</td>
                                <td><input type="text" id="name" name="name"class="input-sm form-control" maxlength="45" minlength="5" style="width: 100%;" value="<?php print $reservation['name'] ?>" />
                                </td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td><input type="email" id="" class="input-sm form-control" maxlength="40" minlength="10" name="email" style="width: 100%;" value="<?php print $reservation['email'] ?>" />
                                </td>
                            </tr>

                            <tr>
                                <td>Celular</td>
                                <td><input type="text" id="" style="width: 70%;" class="input-sm form-control" maxlength="9" name="Celular" value="<?php print $reservation['Celular'] ?>" />
                                </td>
                            </tr>
                            <tr>
                                <td>CheckIn</td>
                                <td><input type="text" id="start" class="input-sm form-control" name="start" style="width: 70%;" value="<?php print $reservation['start'] ?>" />
                                </td>
                            </tr>
                            <tr>
                                <td>CheckOut</td>
                                <td><input type="text" id="end" class="input-sm form-control" name="end" style="width: 70%;" value="<?php print $reservation['end'] ?>" />
                                </td>
                            </tr>
                            <tr>
                                <td>Cómodo</td>
                                <td><select id="room" class="input-sm form-control" style="width: 70%;" name="room">
                                        <?php 
                                            foreach ($rooms as $room) {
                                                $selected = $reservation['room_id'] == $room['id'] ? ' selected="selected"' : '';
                                                $id = $room['id'];
                                                $name = $room['name'];
                                                print "<option value='$id' $selected>$name</option>";
                                            }
                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Estado</td>
                                <td><select id="status" class="input-sm form-control" style="width: 70%;" maxlength="9" name="status">
                                        <?php 
                                            $options = array("Nova reserva", "Confirmada");
                                            foreach ($options as $option) {
                                                $selected = $option == $reservation['status'] ? ' selected="seleccionada"' : '';
                                                $id = $option;
                                                $name = $option;
                                                print "<option value='$id' $selected>$name</option>";
                                            }
                                        ?>
                                    </select> 
                                </td>
                            </tr>
                            <tr>
                                <td>Modo de Pagamento</td>
                                
                                <td>
                                    <select name="modo_pagamento" class="input-sm form-control" style="width:70% ;">
                                        <?php 
                                                $options = array("Presencial", "Pós-pagamento");
                                                foreach ($options as $option) {
                                                    $selected = $option == $reservation['modo_pagamento'] ? ' selected="seleccionada"' : '';
                                                    $id = $option;
                                                    $name = $option;
                                                    print "<option value='$id' $selected>$name</option>";
                                                }
                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Valor pago</td>
                                <td><input type="text" id="" class="input-sm form-control" name="valor_pago" style="width: 70%;" value="<?php print $reservation['valor_pago'] ?>" /></td>
                            </tr>
                            <tr>
                                <?php 
                                    $room_id=$reservation['room_id'];
                                    $stmt = $db->prepare('SELECT * FROM rooms WHERE id = :room_id');
                                    $stmt->bindParam(':room_id', $room_id);
                                    $stmt->execute();
                                    $room = $stmt->fetch();

                                    $num_dias=strtotime($reservation['end'])-strtotime($reservation['start'])-86400;
                                    $num_dias=date('d',$num_dias);
                                    if($num_dias>1) $dias=" dias"; else $dias=" dia ";
                                    $preco=number_format($room['Preco']*$num_dias, 2);
                                ?>
                                <td><label>Total a pagar </label></td>
                                <td><label> <?php echo $preco."</label> AOA\t- ".$num_dias.$dias?></td>
                            </tr>
                        </table>
                  
                    
            
            <div class="space col-md-12"><input type="submit" class="btn btn-primary" value="Save" /> <a class="btn btn-warning" href="javascript:close();">Cancel</a></div></div>
        </form>
        
        <script type="text/javascript">
        function close(result) {
            if (parent && parent.DayPilot && parent.DayPilot.ModalStatic) {
                parent.DayPilot.ModalStatic.close(result);
            }
        }

        $("#f").submit(function () {
            var f = $("#f");
            $.post(f.attr("action"), f.serialize(), function (result) {
                close(eval(result));
            });
            return false;
        });

        $(document).ready(function () {
            $("#name").focus();
        });
    
        </script>
    </body>
</html>
