 <?php
	include_once("principal.php");


    $nome = $_POST['nome'];
	$celular = $_POST['celular'];
    $assunto = $_POST['assunto'];
    $texto = $_POST['texto'];
    $idUsuario = $_SESSION['idUsuario'];
    $data=Date('Y-m-d h:i:s');


				//Inserindo os dados do formulario usercadastrar na tabela usuarios
				 $inserir = mysqli_query($conectar,"INSERT INTO mensagens (id, nome, celular, assunto, mensagem, data) VALUES ('$idUsuario', '$nome', '$celular', '$assunto','$texto', '$data')");
               
				if($inserir){
				$_SESSION['mensagem'] = "
													<div class='col-md-9 col-md-offset-0'>
														<div class='alert alert-success' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															A mensagem foi enviada com successo!
														</div>
												   	</div>";
				}else{
					$_SESSION['mensagem'] = "
													<div class='col-md-9 col-md-offset-0'>
														<div class='alert alert-danger' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															Mensagem não enviada! $idUsuario
														</div>
												   	</div>";
													// echo mysqli_error();
				}
				//Manda o usuario para a tela de login
				header("Location: mensagens.php");

		



?>
    
<?php
	include_once("rodape.php");
?>