<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Nova reserva</title>
    	<link type="text/css" rel="stylesheet" href="media/layout.css" />    
        <link href="bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet">
        <script src="js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
    </head>
    <body>
        <?php
            // check the input
            //is_numeric($_GET['id']) or die("invalid URL");
            
            require_once '_db.php';
            
            $rooms = $db->query('SELECT * FROM rooms');
            
            $start = $_GET['start']; // TODO parse and format
            $end = $_GET['end']; // TODO parse and format
        ?>
        <form id="f" class="form" action="backend_create.php" style="padding:20px;">
            <div class="modal-header">
                <h1>Nova Reserva</h1>
            </div>
            
            <table class="table">
                            <tr>
                                <td>Empresa</td>
                                <td><input type="text" id="empresa" class="input-sm form-control" maxlength="45" minlength="2" style="width: 100%;" name="empresa" value="" />
                                </td>
                            </tr>
                            <tr>
                                <td>Nome</td>
                                <td><input type="text" id="name" name="name"class="input-sm form-control" maxlength="45" minlength="5" style="width: 100%;" value="" />
                                </td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td><input type="email" id="email" name="email" class="input-sm form-control" maxlength="40" minlength="10"  style="width: 100%;" value="" />
                                </td>
                            </tr>

                            <tr>
                                <td>Celular</td>
                                <td><input type="text" id="" name="Celular" style="width: 70%;" class="input-sm form-control" maxlength="9" value="" />
                                </td>
                            </tr>
                            <tr>
                                <td>Adultos</td>
                                <td>
                                    <select name="Adultos" class="input-sm form-control" id="" style="width: 70%;" class="input-sm form-control">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Crianças</td>
                                <td>
                                    <select name="Criancas" id="" class="input-sm form-control"   style="width: 70%;" class="input-sm form-control">
                                        <option value="0">0</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td>CheckIn</td>
                                <td><input type="text" id="start" name="start"  class="input-sm form-control" style="width: 70%;" value="<?php echo $start ?>" />
                                </td>
                            </tr>
                            <tr>
                                <td>CheckOut</td>
                                <td><input type="text" id="end" name="end"  class="input-sm form-control" style="width: 70%;"  value="<?php echo $end ?>" />
                                </td>
                            </tr>
                            <tr>
                                <td>Cómodo</td>
                                <td>
                                    <select id="room" name="room" class="input-sm form-control"  style="width: 70%;" >
                                    <?php 
                                        foreach ($rooms as $room) {
                                            $selected = $_GET['resource'] == $room['id'] ? ' selected="selected"' : '';
                                            $id = $room['id'];
                                            $name = $room['name'];
                                            print "<option value='$id' $selected>$name</option>";
                                        }
                                    ?>
                                </select>
                                </td>
                            </tr>
                            <tr>
                                <td>Estado</td>
                                <td><select id="status" class="input-sm form-control" style="width: 70%;" maxlength="9" name="status">
                                        <?php 
                                            $options = array("Nova reserva", "Confirmada");
                                            foreach ($options as $option) {
                                                $selected = $option == $reservation['status'] ? ' selected="seleccionada"' : '';
                                                $id = $option;
                                                $name = $option;
                                                print "<option value='$id' $selected>$name</option>";
                                            }
                                        ?>
                                    </select> 
                                </td>
                            </tr>
                            <tr>
                                <td>Modo de Pagamento</td>
                                <td><select name="modo_pagamento" class="input-sm form-control" style="width:70% ;">
                                    <option value=""></option>
                                    <option value="Presencial">Presencial</option>
                                    <option value="Pós-pagamento">Pós-pagamento</option>
                                </select></td>
                            </tr>
                            <tr>
                                <td>Valor pago</td>
                                <td><input type="text" id="" class="input-sm form-control" name="valor_pago" style="width: 70%;" value="" /></td>
                            </tr>
                            <tr>
                                <?php 
                                    $room_id=$_GET['resource'];
                                    $stmt = $db->prepare('SELECT * FROM rooms WHERE id = :room_id');
                                    $stmt->bindParam(':room_id', $room_id);
                                    $stmt->execute();
                                    $room = $stmt->fetch();
                                    
                                    //Total dias
                                    $num_dias=strtotime($end)-strtotime($start)-86400;
                                    $num_dias=date('d',$num_dias);
                                    if($num_dias>1) $dias=" dias"; else $dias=" dia ";
                                    $preco=number_format($room['Preco']*$num_dias, 2);
                                ?>
                                <td><label>Total a pagar </label></td>
                                <td><label> <?php echo $preco."</label> MZN\t- ".$num_dias.$dias?> </td>
                            </tr>
                            <tr><td>
                                <input type="submit" class="btn btn-primary" value="Save" /> <a class="btn btn-warning" href="javascript:close();">Cancelar</a>
                            </td></tr>
                            
                        </table>
        </form>
        
        <script type="text/javascript">
        function close(result) {
            if (parent && parent.DayPilot && parent.DayPilot.ModalStatic) {
                parent.DayPilot.ModalStatic.close(result);
            }
        }

        $("#f").submit(function () {
            var f = $("#f");
            $.post(f.attr("action"), f.serialize(), function (result) {
                close(eval(result));
            });
            return false;
        });

        $(document).ready(function () {
            $("#name").focus();
        });
    
        </script>
    </body>
</html>
