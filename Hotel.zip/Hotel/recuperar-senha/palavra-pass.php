<?php
require_once "principaldelogin.php";
require_once "connexao.php";

$email=$_POST['email'];

$sql="SELECT * FROM tabela_usuario WHERE email='$email'";
$resultado=mysqli_query($conectar,$sql);
$dados=mysqli_fetch_array($resultado);

//$id=$_GET['id'];
if(mysqli_num_rows($resultado)>0){
   
    //echo 

     //$pass=MD5($dados['senha']);

     //echo "<br> $pass";
     

?>
<form class="row g-3 needs-validation" method="post" action="alterar-senha.php?id=<?php echo $dados['id']; ?>">
<center>
<div class="col-md-2">
<label for="validationCustom01" class="form-label"><b>E-mail</b> </label>
<div class="input-group has-validation">
<span class="input-group-text" id="inputGroupPrepend">@</span>
                  <input type="text" class="form-control" id="validationCustom01" value="<?php echo $dados['email'];?>" name="nome" disabled>
                  </div>
          </div>
          </div>
          <br>
          <div class="col-md-2">
          <button class="btn btn-primary" type="submit">Alterar a Senha</button>
         
                  </div>
          </div>
          <br>
  <!-- <div class="col-12">
    <button type="submit" class="btn btn-primary">Entrar</button>
  </div> -->
</center>
</form>
<?php
}
else{
    print "<script>alert ('Email não encontrado')</script>";
    require_once "recuperar-senha1.php";

}
?>

