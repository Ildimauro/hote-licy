<head>
<title>Dados actualizados</title>
</head>
<?php
require_once "connexao.php";

$senha=mysqli_escape_string($conectar,$_POST['senha']);
$conf=mysqli_escape_string($conectar,$_POST['conf']);
$id=$_POST['id'];



if ($senha!=$conf){
    print "<script>alert('Senhas diferente!')</script>";
    // require_once "alterar-senha.php";
    // echo "<center> digite senhas correspondentes </center>";
    header("Location: recuperar-senha1.php");
}
else{
     //print "<script>alert('Senha diferente')</script>";
     $criptosenha=md5($senha);

     //Verificar dados existente na tabela
     // * (asterisco) abaixo inserido significa "selecionar tudo", caso queira especificar entao coloca o nome do campo, ex:"bi".
      $sql="UPDATE tabela_usuario SET senha='$criptosenha' WHERE id='$id'";
      $resultado=mysqli_query($conectar,$sql);
      
      if($resultado){
        print "<script>alert('Senha Actualizado com sucesso!')</script>";
       header("Location: listarusuario.php");
       //require_once "listarusuario.php";
        }
        else{
       
        print "<script>alert('Erro ao Actualizar a Senha!')</script>";
        }
}
// //inserindo os dados na tabela, usa-se INSERT INTO



?>