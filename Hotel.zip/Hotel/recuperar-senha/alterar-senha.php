<?php
require_once "principaldelogin.php";
require_once "connexao.php";

$id=$_GET['id'];

$sql="SELECT * FROM tabela_usuario WHERE id='$id'";
$resultado=mysqli_query($conectar,$sql);
$dados=mysqli_fetch_array($resultado);
?>

<form method="post" action="actualizar-senha.php" >
    <center>
<font color="blue">
<label><ha2>Editar Senha</ha2></label>
</font>
<br>
<br>
<input Type="hidden" name="id" value="<?php echo $dados['id'];?>">
Nova Senha<br>
<input type="password" name="senha" required><br>
confirmar a senha<br>
<input type="password" name="conf" required><br>
<br>
<button class="btn btn-primary" type="submit">Actualiza Senha</button>
</center>
</form>
