<?php
require_once "principaldelogin.php";
?>

<form class="row g-3 needs-validation" method="post" action="palavra-pass1.php">
    <input Type="hidden" name="id" value="<?php echo $dados['id']; ?>">

    <center>
<div class="col-md-2">
    <label for="validationCustomUsername" class="form-label"><b>Digite o seu E-mail</b></label>
    <div class="input-group has-validation">
      <span class="input-group-text" id="inputGroupPrepend">@</span>
      <input type="text" class="form-control" id="validationCustomUsername" name="email" aria-describedby="inputGroupPrepend" required>
    </div>
  </div>
<br>
<div class="col-12">
<button class="btn btn-primary" type="submit">Recuperar</button>
  </div>
</center>
</form>

