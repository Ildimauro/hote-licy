<?php
	include_once("principal.php");

?>

<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript" charset="utf-8" ></script>
<script type="text/javascript">
	$(document).ready(function() {
		$('#myTable').DataTable( {
		"language": {
		"lengthMenu": "Mostrando _MENU_ registros por pagina",
		"zeroRecords": "Nada encontrado - Desculpe",
		"info": "Visualisando _PAGE_ de _PAGES_",
		"infoEmpty": "Sem registros disponiveis",
		"infoFiltered": "(Filtrado de _MAX_ registros totais)"
		}
		} );
		} );
		
</script>

<?php
	if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
	}
?>
<?php
 
if (isset($_POST['buscar'])) {
    $pesquisar = $_POST['PalavraChave'];
    $resultado = mysqli_query($conectar,"select * from alojamento where Tipo LIKE '$pesquisar%' OR `Tipo` LIKE '$pesquisar%'");
    
}else{
	$resultado = mysqli_query($conectar,"SELECT * FROM alojamento ORDER BY 'Tipo'");
	
}



?>
<div class="container-fluid">
<div class="row-fluid">
<div class="col col-lg-H col-md-H col-sm-H haggy">
    <div class="panel panel-default panel-table">
        <div class="panel-heading" >
            
              <p>
              	
                	<div class="divH"><label>Entradas</label></div>
                	<div class="text-right divH">
                		 <a href="Criar_Alojamento.php?usuarioId=<?php echo $_SESSION['usuarioId'] ?>"><button type='button' class='text-right btn btn-sm btn-info'><span class="glyphicon glyphicon-plus"></span> </button></a>
                	</div>
                
              </p> 
        </div>	 
        <div class="panel-body">
			

            	
					<!-- <form name="form2" method="post" action="">
						<div class="col-sm-3  form-group" >
							<input type="text" class="input-sm form-control" name="PalavraChave" maxlength="30" size='25' placeholder="Numero do processo ou nome" required="">
				    	</div>
				   		<div class="col-sm-1 col-md-1">
							<button class='btn btn-sm btn-success' name='buscar'><span class="glyphicon glyphicon-search"></span> Pesquisar</button>
				    	</div>
					</form> -->
                

              <div class="col col-xs-12 col-md-12 col-sm-12 col-lg-12">
              		<p class="hidden">
              			
								<label for="texto">Número de Alojamentos: <?php  $num = mysqli_num_rows($resultado);  echo "$num"; ?></label>
              		</p> 
            <div class="row-fluid">
			  
			<form name="form1" method="post" action="">
			   
                
			<div class="row-fluid" >
			<?php
			  
				while($linhas = mysqli_fetch_array($resultado)){
					?>
					<div class="col-lg-3 col-md-3 col-sm-3 panel panel-default panel-table">
						<br>
						<dl class="dl-horizontal">
							<?php
								echo "<dt class='text-left'> Número de Cómodo :</dt> <dd >".$linhas['id']."</dd>";
		                        echo "<dt> Tipo de Cómodo :</dt> <dd >".$linhas['Tipo']."</dd>";
								echo "<dt> Número de Quartos :</dt> <dd >".$linhas['Quartos']."</dd>";
								echo "<dt> Área de Quartos :</dt> <dd >".$linhas['area_quartos']."</dd>";
		                        echo "<dt> Limite de Pessoas :</dt> <dd >".$linhas['camas']."</dd>";
								echo "<dt> Preço por dia :</dt> <dd >".$linhas['Preco']."</dd>";
		                        echo "<dt> Estado :</dt>  <dd >".$linhas['Estado']."</dd>";
		                    if ($linhas['Estado']=="Disponivel") {
		                    ?>

		                    <br>
		                    <div align="center">
		                        <button type="button" name="Entrada" data-toggle="modal" data-target="#Entrada" data-whatever="<?php echo $linhas['id']?>" class='btn btn-sm btn-primary btn' ><span class="glyphicon glyphicon-ok-sign"> </span> Fazer Entrada</button>
		                        <br>
		                    <?php 
		                    	}else{
		                    ?>
		                        <button  type="button" class='btn btn-sm btn-danger btn'><span class="glyphicon glyphicon-eye-"></span>Liberar Cómodo</button>
		                        <br>
		                    </div>
		                    <?php 	
		                    	}
		                    ?>
	                        
						</dl>	

					</div>

					<?php
				}
			?>
			</div>
	  </form>
	
</div>
</div>
</div>
</div> <!-- /container -->

<!-- Inicio Modal Apagar -->
		<div class="modal fade" id="Entrada" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<form name="form1" method="POST" action="">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
							<h4 class="modal-title custom_align" id="Heading">Registrar Entrada</h4>
						</div>
						<script type="text/javascript">
							var id =$("#id").value();
						</script>
						<?php
							$query=mysqli_query($conectar,"SELECT * FROM reservas");
		                ?>
						<div class="modal-body">
							<label>Número de Cómodo</label>
							<input type="text" disabled name="id" id="id" class="form-control">

							<label>Reserva</label>
							<select class="input sm form-control" name="reserva" required="">
								<option></option>
							<?php 
				                while($linhas=mysqli_fetch_array($query)){ 
				                    echo "<option value = '".$linhas['id']."'>".$linhas['Nome']."</option>";
				                }
				            ?>
							</select>
						</div>
						<div class="modal-footer ">
							<button type="submit" class="btn btn-success" ><span class="glyphicon glyphicon-ok-sign"></span> Sim</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Não</button>
						</div>
					
				</div> 
			</div>
		</div> </form>
				<!-- Fim Modal -->


				<script type="text/javascript">
				$('#Entrada').on('show.bs.modal', function (event) {
				  var button = $(event.relatedTarget) // Button that triggered the modal
				  var recipient = button.data('whatever') 
				  var modal = $(this)
				  //modal.find('.modal-title').text('Editar Usuario - idUsuario: ' + recipient)
				  modal.find('#id').val(recipient)
				
				  })
	</script>

<?php
	include_once("rodape.php");
?>