<?php
require_once '_db.php';
session_start();
$stmt = $db->prepare("UPDATE reservations SET empresa = :empresa, name = :name, Celular = :Celular, valor_pago = :valor_pago, modo_pagamento = :modo_pagamento, email = :email, start = :start, end = :end, room_id = :room, status = :status, paid = :paid, usuarioAtualizacao = :usuarioAtualizacao, DataAtualizacao = NOW() WHERE id = :id");

/*if ($_POST['status']=="Confirmada") {
	$pagamento=100;
	$stmt->bindParam(':paid', $pagamento);
}else $stmt->bindParam(':paid', $_POST['paid']);*/
$stmt->bindParam(':paid', $_POST['paid']);
$stmt->bindParam(':id', $_POST['id']);
$stmt->bindParam(':empresa', $_POST['empresa']);
$stmt->bindParam(':modo_pagamento', $_POST['modo_pagamento']);
$stmt->bindParam(':valor_pago', $_POST['valor_pago']);
$stmt->bindParam(':name', $_POST['name']);
$stmt->bindParam(':Celular', $_POST['Celular']);
$stmt->bindParam(':email', $_POST['email']);
$stmt->bindParam(':start', $_POST['start']);
$stmt->bindParam(':end', $_POST['end']);
$stmt->bindParam(':room', $_POST['room']);
$stmt->bindParam(':status', $_POST['status']);
$stmt->bindParam(':usuarioAtualizacao',$_SESSION['usuarioId']);


$stmt->execute();

class Result {}

$response = new Result();
$response->result = 'OK';
$response->message = 'Actualizacão feita com sucesso';

header('Content-Type: application/json');
echo json_encode($response);

?>
