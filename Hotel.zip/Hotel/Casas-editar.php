 <?php
include_once("principal.php");
	
?>
<?php
	if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
	}


	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$_SESSION['id']= $id;
	}
	$id= $_SESSION['id'];
	//Executa consulta
	$result = mysqli_query($conectar,"SELECT * FROM alojamento WHERE id = '$id' LIMIT 1");
	$resultado = mysqli_fetch_assoc($result);
?>

<div class="container-fluid">
<div class="row-fluid">
<div class="col col-lg-H col-md-H col-sm-H haggy">
	
    <div class="panel panel-default panel-table">
        <div class="panel-heading" >
			   
			<p>	              	
	            <div class="divH"><label>Editar Cómodo</label></div>  
	        </p> 
		</div>
		<div class="panel-body">
          <form class="form-horizontal" name="Alojamento" method="POST" >
   
		  		
			<div class="col-sm-12">
			  <div class="form-group">
				
				<div class="col-sm-4">
				Tipo de Cómodo:
				<input type="hidden" value="<?php echo $resultado['id']?>" name="id">
				<input type="text" readonly class="input-sm form-control" required="" value="<?php echo $resultado['Tipo']?>" name="Tipo">
				</div>
				
				
				<div class="col-sm-4">
					Preço :
					  <input type="text" class="input-sm form-control" name="Preco" value="<?php echo $resultado['Preco']?>" maxlength="8" placeholder="MZN / NOITE" required="">
				</div>
				
			  </div>
			</div>
			
         
				<div class="col-sm-6 col col-xs-6 text-left">
				  <button type='button' onclick="Voltar()" class='btn  btn-info'><span class="glyphicon glyphicon-remove"></span>Voltar</button>
				</div>
				<div class="col-sm-6 col col-xs-6 text-right"> 
				  <button type="submit" name="Alojamento" class="btn btn-success"><span class="glyphicon glyphicon-floppy-disk"></span> Gravar</button>
				</div>
				</form>

</div>
</div>
</div>
</div>
 <?php 

if(isset ($_POST['Alojamento'])){
    
    $id = $_SESSION['id'];
    $Tipo = $_POST['Tipo'];
   
    $Preco = $_POST['Preco'];
    
				//Inserindo os dados do formulario usercadastrar na tabela usuarios
				 $inserir = mysqli_query($conectar,"UPDATE alojamento SET Tipo='$Tipo', Preco ='$Preco' WHERE id ='$id'");
				 $inserir = mysqli_query($conectar,"UPDATE rooms SET Preco ='$Preco' WHERE tipo='$Tipo'");
				
				if ($inserir) {
					$_SESSION['mensagem'] = "
													
														<div class='alert alert-success' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															Dados do alojamento editados com sucesso!.
														</div>
												   	";
					unset($_SESSION['id']);
					//Manda o usuario para a tela de login
					header("Location: Casas.php");
				}else{
					$_SESSION['mensagem'] = "
													
														<div class='alert alert-danger' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															
															Error: ".mysqli_error($conectar)."
														</div> 
												   	";
					header("Location: Casas-editar.php");
				}
						
	}

?>
	
<?php
	include_once("rodape.php");
?>