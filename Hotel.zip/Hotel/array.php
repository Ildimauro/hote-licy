<?php

$datas = new DatePeriod(new DateTime(Date('d-m-Y')), new DateInterval('P1M'), 10);
$i=1;
foreach($datas as $data) {
	echo $data->format('d/m/Y'),'<br>';
	echo $i.'<br>';
	$i++;
}

?>