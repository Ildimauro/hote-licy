function Voltar() {
		window.history.go(-1);
}