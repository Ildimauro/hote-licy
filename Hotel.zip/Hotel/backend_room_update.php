<?php
require_once '_db.php';

$stmt = $db->prepare("UPDATE rooms SET name = :name, capacity = :capacity, Preco = :Preco, status = :status WHERE id = :id");
$stmt->bindParam(':id', $_POST['id']);
$stmt->bindParam(':name', $_POST['name']);

$stmt->bindParam(':capacity', $_POST['capacity']);
$stmt->bindParam(':Preco', $_POST['Preco']);
$stmt->bindParam(':status', $_POST['status']);
$stmt->execute();


class Result {}

$response = new Result();
$response->result = 'OK';
$response->message = 'Actualizacão feita com sucesso';

header('Content-Type: application/json');
echo json_encode($response);

?>
