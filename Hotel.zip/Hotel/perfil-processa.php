<?php
//session_start();
include_once("principal.php");
include_once("seguranca.php");
include_once("conexao.php");
//Variavel sessao
$idUsuario = $_SESSION['usuarioLogin'];
$Nivelacesso=$_SESSION['usuarioNivelAcesso'];

$NovoidUsuario = $_POST["usuario"];
$contacto = $_POST["contacto"];
$email = $_POST["email"];

	$query = mysqli_query($conectar,"UPDATE login set usuario ='$NovoidUsuario' WHERE usuario='$idUsuario'");
	$query = mysqli_query($conectar,"UPDATE reservations set usuarioReserva ='$NovoidUsuario' WHERE usuarioReserva='$idUsuario'");
	$query = mysqli_query($conectar,"UPDATE reservations set usuarioAtualizacao='$NovoidUsuario' WHERE usuarioAtualizacao='$idUsuario'");
	$query = mysqli_query($conectar,"UPDATE tabela_usuarios set  idUsuario  = '$NovoidUsuario', dataModificacao = NOW() WHERE idUsuario='$idUsuario'");
	if($query){
	$_SESSION['mensagem'] = "
												
													<div class='alert alert-success' role='alert'> 
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														Dados actualizados com sucesso!
													</div>
											   	";
		$_SESSION['usuarioId']=$NovoidUsuario;
		$_SESSION['usuarioLogin']= $NovoidUsuario;
	}else{
			$_SESSION['mensagem'] = "
												<div class='alert alert-danger' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															Error: ".mysqli_error($conectar)."
														</div> 
											   	";
		
	}
		//Manda o usuario para a tela de notificacao
		header("Location: perfil.php");

