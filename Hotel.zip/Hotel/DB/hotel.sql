-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 10-Out-2021 às 12:10
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `acessos`
--

CREATE TABLE `acessos` (
  `id` bigint(20) NOT NULL,
  `ip` varchar(16) NOT NULL,
  `data` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `alojamento`
--

CREATE TABLE `alojamento` (
  `id` smallint(6) NOT NULL,
  `Tipo` varchar(20) NOT NULL,
  `Quartos` tinyint(1) NOT NULL,
  `area_quartos` int(11) NOT NULL,
  `camas` tinyint(1) NOT NULL,
  `Preco` int(11) NOT NULL,
  `Estado` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `alojamento`
--

INSERT INTO `alojamento` (`id`, `Tipo`, `Quartos`, `area_quartos`, `camas`, `Preco`, `Estado`) VALUES
(1, 'Casa VIP', 1, 5, 4, 12000, 'Disponivel'),
(2, 'Stardard', 1, 5, 1, 4500, 'Disponivel'),
(3, 'Duplo', 1, 5, 2, 4500, 'Disponivel');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `ID` int(11) NOT NULL,
  `Nome` varchar(25) NOT NULL,
  `Apelido` varchar(25) NOT NULL,
  `BI` varchar(13) NOT NULL,
  `Naturalidade` varchar(20) NOT NULL,
  `Pais` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Contacto` bigint(11) NOT NULL,
  `Sexo` varchar(15) NOT NULL,
  `Estado` varchar(9) NOT NULL,
  `Bairro` varchar(20) NOT NULL,
  `dataCadastro` date NOT NULL,
  `dataMod` date NOT NULL,
  `idUsuario` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `login`
--

CREATE TABLE `login` (
  `id` bigint(20) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `data` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) COLLATE utf8_bin NOT NULL,
  `apelido` varchar(20) COLLATE utf8_bin NOT NULL,
  `celular` int(9) NOT NULL,
  `email` varchar(40) COLLATE utf8_bin NOT NULL,
  `msg` varchar(1000) COLLATE utf8_bin NOT NULL,
  `Estado` tinyint(4) NOT NULL,
  `data` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `notificacoes`
--

CREATE TABLE `notificacoes` (
  `ID` bigint(20) NOT NULL,
  `Titulo` varchar(50) NOT NULL,
  `Texto` text NOT NULL,
  `idNivel_acesso` int(11) NOT NULL,
  `Data` date NOT NULL,
  `Estado` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `reservas`
--

CREATE TABLE `reservas` (
  `id` bigint(20) NOT NULL,
  `CheckIn` datetime NOT NULL,
  `CheckOut` datetime NOT NULL,
  `Alojamento` varchar(20) NOT NULL,
  `empresa` varchar(30) DEFAULT NULL,
  `Nome` varchar(50) NOT NULL,
  `Celular` bigint(9) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `N_Adultos` tinyint(1) NOT NULL,
  `N_Criancas` tinyint(1) NOT NULL DEFAULT '0',
  `DataReserva` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `Celular` int(9) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `N_Adultos` tinyint(4) NOT NULL,
  `N_Criancas` tinyint(4) DEFAULT '0',
  `empresa` varchar(40) DEFAULT NULL,
  `DataReserva` datetime NOT NULL,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT 'Nova reserva',
  `valor_pago` int(11) DEFAULT '0',
  `modo_pagamento` varchar(15) DEFAULT 'Presencial',
  `paid` int(11) DEFAULT '0',
  `usuarioReserva` varchar(50) NOT NULL,
  `usuarioAtualizacao` varchar(50) NOT NULL,
  `DataAtualizacao` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `tipo` varchar(20) NOT NULL,
  `Preco` int(11) NOT NULL,
  `status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `rooms`
--

INSERT INTO `rooms` (`id`, `name`, `capacity`, `tipo`, `Preco`, `status`) VALUES
(1, 'Casa VIP', 4, 'Casa VIP', 12000, 'Disponivel'),
(2, '1-A', 1, 'Standard', 4500, 'Disponivel'),
(3, '1-B', 2, 'Duplo', 4500, 'Disponivel'),
(4, '2-A', 1, 'Standard', 4500, 'Disponivel'),
(5, '2-B', 2, 'Duplo', 4500, 'Disponivel'),
(6, '3-A', 1, 'Standard', 4500, 'Disponivel'),
(7, '3-B', 2, 'Duplo', 4500, 'Disponivel'),
(8, '4-A', 1, 'Standard', 4500, 'Disponivel'),
(9, '4-B', 2, 'Duplo', 4500, 'Disponivel'),
(10, '5-A', 1, 'Standard', 4500, 'Disponivel'),
(11, '5-B', 2, 'Duplo', 4500, 'Disponivel'),
(12, '6-A', 1, 'Standard', 4500, 'Disponivel'),
(13, '6-B', 2, 'Duplo', 4500, 'Disponivel'),
(14, '7-A', 1, 'Standard', 4500, 'Disponivel'),
(15, '7-B', 2, 'Duplo', 4500, 'Disponivel'),
(16, '8-A', 1, 'Standard', 4500, 'Disponivel'),
(17, '8-B', 2, 'Duplo', 4500, 'Disponivel'),
(18, '9-A', 1, 'Standard', 4500, 'Disponivel'),
(19, '9-B', 2, 'Duplo', 4500, 'Disponivel'),
(20, '10-A', 1, 'Standard', 4500, 'Disponivel'),
(21, '10-B', 2, 'Duplo', 4500, 'Disponivel'),
(22, '11-A', 1, 'Standard', 4500, 'Disponivel'),
(23, '11-B', 2, 'Duplo', 4500, 'Disponivel'),
(24, '12-A', 1, 'Standard', 4500, 'Disponivel'),
(25, '12-B', 2, 'Duplo', 4500, 'Disponivel'),
(26, '13-A', 1, 'Standard', 4500, 'Disponivel'),
(27, '13-B', 2, 'Duplo', 4500, 'Disponivel'),
(28, '14-A', 1, 'Standard', 4500, 'Disponivel'),
(29, '14-B', 2, 'Duplo', 4500, 'Disponivel'),
(30, '15-A', 1, 'Standard', 4500, 'Disponivel'),
(31, '15-B', 2, 'Duplo', 4500, 'Disponivel'),
(32, '16-A', 1, 'Standard', 4500, 'Disponivel'),
(33, '16-B', 2, 'Duplo', 4500, 'Disponivel'),
(34, '17-A', 1, 'Standard', 4500, 'Disponivel'),
(35, '17-B', 2, 'Duplo', 4500, 'Disponivel'),
(36, '18-A', 1, 'Standard', 4500, 'Disponivel'),
(37, '18-B', 2, 'Duplo', 4500, 'Disponivel'),
(38, '19-A', 1, 'Standard', 4500, 'Disponivel'),
(39, '19-B', 2, 'Duplo', 4500, 'Disponivel');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tabela_nivel_acesso`
--

CREATE TABLE `tabela_nivel_acesso` (
  `idNivelAcesso` int(11) NOT NULL,
  `nomeNivelAcesso` varchar(50) NOT NULL,
  `DataCadastro` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tabela_nivel_acesso`
--

INSERT INTO `tabela_nivel_acesso` (`idNivelAcesso`, `nomeNivelAcesso`, `DataCadastro`) VALUES
(1, 'Administrador  full  ', '2017-08-24'),
(2, 'Recepcao', '2017-08-24');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tabela_usuarios`
--

CREATE TABLE `tabela_usuarios` (
  `idUsuario` varchar(50) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `estado` varchar(10) NOT NULL,
  `idNivelAcesso` int(11) NOT NULL,
  `dataCadastro` date NOT NULL,
  `dataModificacao` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tabela_usuarios`
--

INSERT INTO `tabela_usuarios` (`idUsuario`, `nome`, `senha`, `estado`, `idNivelAcesso`, `dataCadastro`, `dataModificacao`) VALUES
('Admin', 'Haggy Manjolo', '21232f297a57a5a743894a0e4a801fc3', 'Activo', 1, '2019-03-12', '2019-03-21');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo quartos`
--

CREATE TABLE `tipo quartos` (
  `id` tinyint(4) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `camas` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acessos`
--
ALTER TABLE `acessos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `alojamento`
--
ALTER TABLE `alojamento`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `Contacto` (`Contacto`),
  ADD UNIQUE KEY `idUsuario` (`idUsuario`),
  ADD UNIQUE KEY `BI` (`BI`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario` (`usuario`);

--
-- Indexes for table `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notificacoes`
--
ALTER TABLE `notificacoes`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Nome` (`Nome`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `usuarioAtualizacao` (`usuarioAtualizacao`),
  ADD KEY `usuarioReserva` (`usuarioReserva`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabela_nivel_acesso`
--
ALTER TABLE `tabela_nivel_acesso`
  ADD PRIMARY KEY (`idNivelAcesso`);

--
-- Indexes for table `tabela_usuarios`
--
ALTER TABLE `tabela_usuarios`
  ADD PRIMARY KEY (`idUsuario`),
  ADD KEY `idNivelAcesso` (`idNivelAcesso`);

--
-- Indexes for table `tipo quartos`
--
ALTER TABLE `tipo quartos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acessos`
--
ALTER TABLE `acessos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
--
-- AUTO_INCREMENT for table `alojamento`
--
ALTER TABLE `alojamento`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notificacoes`
--
ALTER TABLE `notificacoes`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;
--
-- AUTO_INCREMENT for table `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `tabela_nivel_acesso`
--
ALTER TABLE `tabela_nivel_acesso`
  MODIFY `idNivelAcesso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `tabela_usuarios`
--
ALTER TABLE `tabela_usuarios`
  ADD CONSTRAINT `tabela_usuarios_ibfk_1` FOREIGN KEY (`idNivelAcesso`) REFERENCES `tabela_nivel_acesso` (`idNivelAcesso`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
