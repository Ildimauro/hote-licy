 <?php
	include_once("principal.php");
?>
<?php
				if(isset($_SESSION['mensagem'])){
					echo $_SESSION['mensagem'];
					unset($_SESSION['mensagem']);
				}
			?>
<div class="container-fluid">
	<div class="row-fluid">
		<div class="col col-lg-H col-md-H col-sm-H haggy">
			
		    <div class="panel panel-default panel-table">
		        <div class="panel-heading" >
					   
					<p>	              	
			            <div class="divH"><label>Formulario de Cadastro Usuário</label></div>  
			        </p> 
				</div>
				<div class="panel-body">
		          	<form class="form-horizontal" method="POST" name="cadastrarUsuario">
		         		  		
						<div class="col-sm-12">
						  <div class="form-group">
							<div class="col-sm-4">
							Nome completo:
							  <input type="text" class="input-sm form-control" name="nome" placeholder="Nome Completo" required="" autofocus="">
							</div>
							<div class="col-sm-4">
							Usuário:
							  <input type="text" class="input sm form-control" name="usuario" placeholder="Usuário" required="">
							</div>
							
							<div class="col-sm-4">
							Nivel de Acesso:
							  <select class="input sm form-control" name="nivel_de_acesso" required="">
							  	<option value="">Selecione aqui</option>
								  <option value="1">Administrador</option>
								  <option value="2">Recepcao</option>
								</select>
							</div>
						  </div>
					  	</div>
					  
					  	<div class="col-sm-12">
						  	<div class="form-group">
								<div class="col-sm-4 col col-xs-12">
									<br>
								  <button type="submit" name="cadastrarUsuario" class="btn btn-success"><span class="glyphicon glyphicon-floppy-disk"></span> Cadastrar</button>
								</div>
						  	</div>
					  	</div>
					  </form>
					</div>
		    	</div>
			</div>
		</div>
	
</div><!-- /container -->
<?php
	include_once("rodape.php");
?>
<?php 

if(isset ($_POST['cadastrarUsuario'])){
    
    
    $nome 				= $_POST["nome"];
	$email 				= $_POST["email"];
	$usuario 			= $_POST["usuario"];
	$senha 				= md5("Platinum2017");
	$confirmacao		= $_POST["confirmacao"];
	$nivel_de_acesso 	= $_POST["nivel_de_acesso"];

	//Verificando os usuários já existentes na Base de Dados
	//Para evitar a duplicação dos dados 
	$verifica_usuario = "SELECT * FROM tabela_usuarios WHERE (usuario = '$usuario')";
	$usuario_resultado = mysqli_query($conectar,$verifica_usuario);
	
	
				$query = mysqli_query($conectar,"INSERT INTO tabela_usuarios (`idUsuario`, `nome`, `senha`, `estado`, `idNivelAcesso`, `dataCadastro`) VALUES ('$usuario', '$nome', '$senha','Activo', '$nivel_de_acesso', NOW())");
				if($query){
					$_SESSION['mensagem'] = "
														
															<div class='alert alert-success' role='alert'>
																<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
																Usuário <strong>$nome</strong> cadastrado com sucesso!<br>
																A senha é Platinum2017, recomendamos que ela seja alterada imediatamente.
															</div>
										";
			
					//Manda o usuario para a tela de login
					header("Location: listarUsuarios.php");
					
				}else{
			
					$_SESSION['mensagem'] = "
														<div class='alert alert-danger' role='alert'> 
																<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
																Error: ".mysqli_error($conectar)."
															</div>
											";


					header("Location: Usuario-cadastro.php");
				}
	}    
?>

<?php
	include_once("rodape.php");
?>