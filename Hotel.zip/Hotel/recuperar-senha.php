<!DOCTYPE html>
<html lang="pt">
    <head>
		<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Hotel Projecto ISI - Recuperação da senha</title>
        <meta name="description" content="Login" />
        <meta name="keywords" content="Login" />
        <meta name="author" content="Hildo Domingos João" />
        
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="bootstrap/css/theme.css" rel="stylesheet">
	<link href="bootstrap/manjolo.css" rel="stylesheet">
    <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>
        <script src="js/modernizr.custom.63321.js"></script>
		<style>
		</style>
    </head>
    <body role="image" background="pics/unnamerrd.png">
        <div class="container">

<form class="row g-3 needs-validation" method="post" action="palavra-pass.php">
    <input Type="hidden" name="id" value="<?php echo $dados['idUsuario']; ?>">

  <div align="center">
<div class="col-md-12">
    <label for="td" class="form-label"><b> Nome do Usuario</b></label>
    <div class="input-group has-validation">
      <p class="clearfix">
      
						<input required autofocus autocomplete="off" name="usuario" type="imputuser" class="form-control" class="td" size="30" maxlength="25" id="username" placeholder=" &#128272;Usuario"/>
      
          </p>
       </div>
</div>

<br>
<div class="col-12">
<button class="btn btn-primary" type="submit">Recuperar</button>
  </div>
</div>
</form>

</body>
</html>