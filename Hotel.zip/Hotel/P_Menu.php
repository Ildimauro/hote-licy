<style type="text/css" media="screen">
	body,html{
    height: 100%;
  }

  nav.sidebar, .main{
    -webkit-transition: margin 200ms ease-out;
      -moz-transition: margin 200ms ease-out;
      -o-transition: margin 200ms ease-out;
      transition: margin 200ms ease-out;
  }
  .divH{
  margin-top: -10px; 
  margin-bottom: -10px;
  }
  .main{
    padding: 10px 10px 0 10px;
  }

 @media (min-width: 765px) {

    .main{
      position: absolute;
      width: calc(100% - 40px); 
      margin-left: 40px;
      float: right;
    }

    nav.sidebar:hover + .main{
      margin-left: 200px;
    }
    nav.sidebar:hover + .co{
      margin-left: -200px;
    }

    nav.sidebar.navbar.sidebar>.container .navbar-brand, .navbar>.container-fluid .navbar-brand {
      margin-left: 0px;
    }

    nav.sidebar .navbar-brand, nav.sidebar .navbar-header{
      text-align: center;
      width: 100%;
      margin-left: 0px;
    }
    
    nav.sidebar a{
      padding-right: 13px;
    }

    nav.sidebar .navbar-nav > li:first-child{
      border-top: 1px #e5e5e5 solid;
    }

    nav.sidebar .navbar-nav > li{
      border-bottom: 1px #e5e5e5 solid;
    }

    nav.sidebar .navbar-nav .open .dropdown-menu {
      position: absolute;
      float: none;
      width: auto;
      margin-top: 0;
      background-color: transparent;
      border: 0;
      -webkit-box-shadow: none;
      box-shadow: none;
    }

    nav.sidebar .navbar-collapse, nav.sidebar .container-fluid{
      padding: 0 0px 0 0px;
    }

    .navbar-inverse .navbar-nav .open .dropdown-menu>li>a {
      color: #777;
    }

    nav.sidebar{
      width: 200px;
      height: 100%;
      margin-left: -160px;
      float: left;
      margin-bottom: 0px;
    }

    nav.sidebar li {
      width: 100%;
    }

    nav.sidebar:hover{
      margin-left: 0px;
    }

    .forAnimate{
      opacity: 0;
    }
  }
</style>
<br class="hidden-xs hidden-sm">
<br class="hidden-xs hidden-sm">
<br class="hidden-xs hidden-sm">
<br class="hidden-xs hidden-sm">
<br class="hidden-xs hidden-sm">
<nav class="navbar navbar-default sidebar"  role="navigation" style="z-index: 1;">
  	<div class="container-fluid">
    	<div class="row-fluid">
    		<div class="navbar-header">
		      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-sidebar-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>      
    		</div>
		    <div class="collapse navbar-collapse" id="bs-sidebar-navbar-collapse-1">
		      <ul class="nav navbar-nav">
		        <li class="active"><a href="inicio.php">Relatório<span style="font-size:16px;" class="pull-right showopacity glyphicon glyphicon-home"></span></a>
		  <?php if ($_SESSION['usuarioNivelAcesso']=="1"){ ?>       <li><a href="funcionario-listar.php?usuarioNivelAcesso=<?php echo $_SESSION['usuarioNivelAcesso']  ?>"> Funcionário <span style="font-size:16px;" class="pull-right glyphicon glyphicon-user"></span></a></li> <?php } ?> 
		 <?php if ($_SESSION['usuarioNivelAcesso']=="1"){ ?>       <li><a href="listarUsuarios.php?usuarioNivelAcesso=<?php echo $_SESSION['usuarioNivelAcesso']  ?>"> Usuarios <span style="font-size:16px;" class="pull-right showopacity glyphicon glyphicon-user"></span></a></li> <?php } ?>
     <?php if ($_SESSION['usuarioNivelAcesso']=="1" OR $_SESSION['usuarioNivelAcesso']=="2"){ ?>       <li><a href="reservas.php?usuarioNivelAcesso=<?php echo $_SESSION['usuarioNivelAcesso']  ?>"> Reservas Online <span style="font-size:16px;" class="pull-right showopacity glyphicon glyphicon-pencil"></span></a></li> <?php } ?>
     <?php if ($_SESSION['usuarioNivelAcesso']=="1"){ ?>       <li class=""><a href="Casas.php?usuarioNivelAcesso=<?php echo $_SESSION['usuarioNivelAcesso']  ?>"> Casas do Hotel <span style="font-size:16px;" class="pull-right showopacity glyphicon glyphicon-bookmark"></span></a></li> <?php } ?>
     <?php if ($_SESSION['usuarioNivelAcesso']=="1"){ ?>       <li><a href="Alojamentos.php?usuarioNivelAcesso=<?php echo $_SESSION['usuarioNivelAcesso']  ?>"> Alojamentos <span style="font-size:16px;" class="pull-right showopacity glyphicon glyphicon-bookmark"></span></a></li> <?php } ?>
      <?php if ($_SESSION['usuarioNivelAcesso']=="1" OR $_SESSION['usuarioNivelAcesso']=="2"){ ?>       <li><a href="index2.php?usuarioNivelAcesso=<?php echo $_SESSION['usuarioNivelAcesso']  ?>"> Marco de Ocupação <span style="font-size:16px;" class="pull-right showopacity glyphicon glyphicon-list-alt"></span></a></li> <?php } ?>
					<li><a data-toggle="collapse" data-parent="#accordion" href="#collapseSeven">Personalizações <span style="font-size:16px;" class="pull-right glyphicon glyphicon-file"></span></a> </li>      
		        <div id="collapseSeven" class="panel-collapse collapse">
		             <ul class="nav navbar-nav">
		             	<?php if ($_SESSION['usuarioNivelAcesso']=="2"){ ?>      <li><a href="perfil.php?login=<?php echo $_SESSION['usuarioLogin'] ?>">&nbsp;&nbsp;&nbsp;Dados pessoais<span style="font-size:20px;" class="pull-right glyphicon glyphicon-cog"></span></a></li><?php } ?>
		              <li><a href="senha-administrador.php?usuarioId=<?php echo $_SESSION['usuarioId'] ?>">&nbsp;&nbsp;&nbsp;Alterar Senha<span style="font-size:20px;" class="pull-right glyphicon glyphicon-barcode"></span></a></li>
		             </ul>
		        </div>  
		      </ul>
		    </div>
  		</div>
  	</div>
</nav>