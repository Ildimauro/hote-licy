 <?php
	include_once("principal.php");
?>
<?php
				if(isset($_SESSION['mensagem'])){
					echo $_SESSION['mensagem'];
					unset($_SESSION['mensagem']);
				}
			?>
			
<div class="container-fluid">
<div class="row-fluid">
<div class="col col-lg-H col-md-H col-sm-H haggy">
	
    <div class="panel panel-default panel-table">
        <div class="panel-heading" >
			   
			<p>	              	
	            <div class="divH"><label>Novo Alojamento</label></div>  
	        </p> 
		</div>
		<div class="panel-body">
          <form class="form-horizontal" name="Alojamento" method="POST" >
   
		  		
			
			  <div class="form-group">
				
				<div class="col-sm-4">
				Nome do Cómodo:
				  <input type="text" class="input-sm form-control" name="name"  required="">
				</div>
				<div class="col-sm-4">
				Tipo:
				  	<select class="input-sm form-control text-left" name="capacity" >
					  	<option value="1">Standard</option>
					  	<option value="2">Duplo</option>
					  	<option value="4">Casa Vip</option>
					</select>
				</div>
			  	<div class="col-sm-4">
					Preço:
					  <input type="text" class="input-sm form-control" name="Preco" minlength="4" placeholder="AOA / NOITE" required="">
				</div>
			
				<div class="col-sm-4">
				Estado:
				  <select class="input sm form-control" name="Estado" >
				  		<option value="">Selecione aqui</option>
					  	<option value="Disponivel">Disponivel</option>
					  	<option value="Bloqueado">Bloqueado</option>
					  	
					</select>
				</div>
			  </div>
			
         
				<div class="text-left">
				  <button type='button' onclick="Voltar()" class='btn  btn-info'><span class="glyphicon glyphicon-remove"></span>Voltar</button>
				</div>
				<div class="text-right"> 
				  <button type="submit" name="Alojamento" class="btn btn-success"><span class="glyphicon glyphicon-floppy-disk"></span> Gravar</button>
				</div>
				</form>

</div>
</div>
</div>
</div>

    
    <?php 

if(isset ($_POST['Alojamento'])){
    $name = $_POST['name'];
    
    $capacity = $_POST['capacity'];
    $Preco = $_POST['Preco'];
    $Estado = $_POST['Estado'];
    
				//Inserindo os dados do formulario usercadastrar na tabela usuarios
				 $inserir = mysqli_query($conectar,"INSERT INTO `rooms`(`name`, `capacity`,`Preco`, `status`) VALUES ('$name','$capacity', '$Preco','$Estado')");
				
				 
                
				if ($inserir) 
					/*$inserir1 = mysqli_query($conectar,"INSERT INTO tabela_usuarios (idUsuario, nome,senha, estado, idNivelAcesso , dataCadastro) VALUES ('$email', '$nome $apelido', '$senha', 'Activo', '2', NOW())");
					if ($inserir1)*/{
					$_SESSION['mensagem'] = "
													
														<div class='alert alert-success' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															Alojamento criado com sucesso!.
														</div>
												   	";
					//Manda o usuario para a tela de login
					header("Location: Alojamentos.php");
				}else{
					$_SESSION['mensagem'] = "
													
														<div class='alert alert-danger' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															
															Error: ".mysqli_error($conectar)."
														</div> 
												   	";
					header("Location: Criar_Alojamento.php");
				}
						
	}


?>
    
<?php
	include_once("rodape.php");
?>