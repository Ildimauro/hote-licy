<!DOCTYPE html>
<html lang="pt">
    <head>
		<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="shortcut icon" href="pics/BG.jpg" type="image/x-icon"> 
        <title>HOTEL LICY/SOYO</title>
        <meta name="description" content="Login" />
        <meta name="keywords" content="Login" />
        <meta name="author" content="Hildo Domingos João" />
        
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="bootstrap/css/theme.css" rel="stylesheet">
	<link href="bootstrap/manjolo.css" rel="stylesheet">
    <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>
        <script src="js/modernizr.custom.63321.js"></script>
		
</head>
<body role="image" background="pics/bg.jpg">
        <div class="col-xs-12  col-lg-4 col-lg-offset-4 col-md-4 col-md-offset-4  col-sm-6 col-sm-offset-3" >
			<br>
			<section class="main"> 
        <form action="Novo-Usuario.php" method="post"><br>
				 	<div class="panel panel-table">
                     <H3>
           <p style="text-align: center;"> NOVO USUÁRIO CADASTRADO COM ÊXITO! </P>
            </H3>
				 		<p class="clearfix">	
							<div  class="panel-primary panel-heading text-center" ><H2 class="panel-title">HOTEL LICY/SOYO</H2>
						</p>

					</div>
					<div class="panel-body"> 
					<div align="center">
					<p class="clearfix">
						<img src="pics/frontal.jpg" class="img-responsive" id="logoildo.png" alt="responsive image">
					</p>
					</div>
					<p class="clearfix" style="color: red">
					<?php
                        if(isset($_SESSION['loginErro'])){
                            echo $_SESSION['loginErro'];
                            unset($_SESSION['loginErro']);
                        }
                    ?>
                   
                    </p>
                    <div align="center">
                   <p>
    <h3>
       Informação do cadastro
    </h3>
</p>
    </div>
<?php
include_once "conexao.php";

$idUsuario=$_POST['idUsuario'];
$Nome=$_POST['nome'];
//$Senha=$_POST['Senha'];
$Senha=md5($_POST['senha']);
$estado=$_POST['estado'];
$idNivelAcesso=$_POST['idNivelAcesso'];
$dataCadastro=$_POST['dataCadastro'];
$dataModificacao=$_POST['dataModificacao'];

$sql= "INSERT INTO tabela_usuarios (idUsuario, nome, senha, estado, idNivelAcesso, dataCadastro, dataModificacao) values('$idUsuario','$Nome','$Senha','$estado','$idNivelAcesso','$dataCadastro','$dataModificacao')";
$res= mysqli_query($conectar,$sql);

echo "<h4>Cadastrado com Sucesso!</h4>";
echo "<b>Nome competo:</b> ".($Nome)."<br>";
echo "<b>Estado:</b> ".($estado)."<br>";

?>

<?php
$NomeSevidor= "localhost";
$NomeUsuario= "root";
$Senha = "";
$BaseDados= "isi";

$conectar=mysqli_connect($NomeSevidor,$NomeUsuario,$Senha,$BaseDados);

//GERADORA DE EMAIL AUTOMATICO

function generateEmail($idUsuario) {
    $partesNome = explode(" ", strtolower($idUsuario));
   // $primeiroNome = $partesNome[0];
    //$sobrenome = end($partesNome);
    $email = $idUsuario. "@gmail.com"; 
     // Substitua "exemplo.com" pelo domínio de e-mail desejado
    return $email;
}

// Exemplo de uso:
$Nome = readline("Digite seu nome USUARIO: ");
$emailidUsuario = generateEmail($idUsuario);
echo "<b>Seu e-mail é:</b> " . $emailidUsuario;
?>


</div>
         </form>
         <form action="index.php" method="post">
         <div align="center"><button>Iniciar sessão</button></div>
</form> <br>

<br>
<form action="site.php" method="post">
<div align="center"><button>Voltar</button></div>
</form> 