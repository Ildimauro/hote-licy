 <?php
include_once("principal.php");
	
?>
<?php
	if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
	}


	if (isset($_GET['id'])) {
		$id = $_GET['id'];
		$_SESSION['id']= $id;
	}
	$id= $_SESSION['id'];
	//Executa consulta
	$result = mysqli_query($conectar,"SELECT * FROM rooms WHERE id = '$id' LIMIT 1");
	$resultado = mysqli_fetch_assoc($result);
?>

<div class="container-fluid">
<div class="row-fluid">
<div class="col col-lg-H col-md-H col-sm-H haggy">
	
    <div class="panel panel-default panel-table">
        <div class="panel-heading" >
			   
			<p>	              	
	            <div class="divH"><label>Editar Alojamento</label></div>  
	        </p> 
		</div>
		<div class="panel-body">
          <form class="form-horizontal" name="Alojamento" method="POST" >
   			<input type="hidden" value="<?php echo $resultado['id']?>" name="id">
			  <div class="form-group">
				<div class="col-lg-4">
				Nome:
					<input type="text" class="input-sm form-control" value="<?php echo $resultado['name']?>" name="name">
				</div>
				<div class="col-lg-4 text-left">
				Tipo:
				<?php 
					if ($resultado['capacity']==1) $tipo="Standard";
					if ($resultado['capacity']==2) $tipo="Duplo";
					if ($resultado['capacity']==4) $tipo="Casa Vip";
				 ?>
				  	<select class="input-sm form-control text-left" name="capacity" >
				  		<option value="<?php echo $resultado['capacity']?>"> <?php echo $tipo?></option>
					  	<option value="1">Standard</option>
					  	<option value="2">Duplo</option>
					  	<option value="4">Casa Vip</option>
					</select>
				</div>
			  	
				<div class="col-lg-4">
					Preço:
					  <input type="text" class="input-sm form-control" name="Preco" value="<?php echo $resultado['Preco']?>" maxlength="8" placeholder="AOA / NOITE" required="">
				</div>
			  
			
				<div class="col-lg-4">
				Estado:
				  <select class="input sm form-control" name="Estado" >
				  		<option value="<?php echo $resultado['status']?>"> <?php echo $resultado['status']?></option>
					  	<option value="Disponivel">Disponivel</option>
					  	<option value="Bloqueado">Bloqueado</option>
					</select>
				</div>
			  
			</div>
			
         
				<div class=" text-left">
				  <button type='button' onclick="Voltar()" class='btn  btn-info'><span class="glyphicon glyphicon-remove"></span>Voltar</button>
				</div>
				<div class="text-right"> 
				  <button type="submit" name="Alojamento" class="btn btn-success"><span class="glyphicon glyphicon-floppy-disk"></span> Gravar</button>
				</div>
				</form>

</div>
</div>
</div>
</div>
 <?php 

if(isset ($_POST['Alojamento'])){
    
    $id = $_SESSION['id'];
    $name = $_POST['name'];
    $capacity = $_POST['capacity'];
    $Preco = $_POST['Preco'];
    $Estado = $_POST['Estado'];
    
				//Inserindo os dados do formulario usercadastrar na tabela usuarios
				 $inserir = mysqli_query($conectar,"UPDATE rooms SET name ='$name', capacity ='$capacity', Preco ='$Preco', status ='$Estado' WHERE id ='$id'");
				
				if ($inserir) {
					$_SESSION['mensagem'] = "
													
														<div class='alert alert-success' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															Dados do rooms editados com sucesso!.
														</div>
												   	";
					unset($_SESSION['id']);
					//Manda o usuario para a tela de login
					header("Location: Alojamentos.php");
				}else{
					$_SESSION['mensagem'] = "
													
														<div class='alert alert-danger' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															
															Error: ".mysqli_error($conectar)."
														</div> 
												   	";
					header("Location: rooms-editar.php");
				}
						
	}

?>
	
<?php
	include_once("rodape.php");
?>