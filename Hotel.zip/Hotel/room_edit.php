<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Editar Comodo</title>
    	<link type="text/css" rel="stylesheet" href="media/layout.css" />    
        <link href="bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet">
        <script src="js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="js/daypilot/daypilot-all.min.js" type="text/javascript"></script>
    </head>
    <body>
        <?php
            // check the input
            is_numeric($_GET['id']) or die("invalid URL");
            
            require_once '_db.php';
            
            $stmt = $db->prepare('SELECT * FROM rooms WHERE id = :id');
            $stmt->bindParam(':id', $_GET['id']);
            $stmt->execute();
            $room = $stmt->fetch();
        ?>
        <form id="f" style="padding:20px;">
            <input type="hidden" name="id" value="<?php print $_GET['id'] ?>" />
            <h1>Editar Cómodo</h1>
            <div>Nome: </div>
            <div><input type="text" id="name" class="input-sm form-control" name="name" style="width: 75%;" value="<?php print $room['name'] ?>" /></div>
            <div>Tipo:</div>
            <div>
                <select id="capacity" class="input-sm form-control" name="capacity" style="width: 75%;">
                    <?php 
                        $options = array(1, 2, 4);
                        foreach ($options as $option) {
                            $selected = $option == $room['capacity'] ? ' selected="Seleccionado"' : '';
                            $id = $option;
                            $name = $option;
                            $cap='';
                            if ($name=='1')  $cap="Standard";
                            elseif ($name=='2') $cap="Duplo";
                            elseif ($name=='4') $cap="Casa Vip";

                            print "<option value='$id' $selected>$cap</option>";
                        }
                    ?>
                </select>                
            </div>
            <div>Preço: </div>
            <div><input type="text" id="Preco" class="input-sm form-control" name="Preco" style="width: 75%;" value="<?php print $room['Preco'] ?>" /></div>
            <div>Estados:</div>
            <div>
                <select id="status" class="input-sm form-control" name="status" style="width: 75%;">
                    <?php 
                        $options = array("Disponivel", "Bloqueado");
                        foreach ($options as $option) {
                            $selected = $option == $room['status'] ? ' selected="Seleccionado"' : '';
                            $id = $option;
                            $name = $option;
                            print "<option value='$id' $selected>$name</option>";
                        }
                    ?>
                </select>                
            </div>

            
            <div class="space"><input type="submit" class="btn btn-primary" value="Save" /> <a href="javascript:close();">Cancelar</a></div>
        </form>
        
        <script type="text/javascript">
        function close(result) {
            DayPilot.Modal.close(result);
        }

        $("#f").submit(function () {
            var f = $("#f");
            $.post("backend_room_update.php", f.serialize(), function (result) {
                close(eval(result));
            });
            return false;
        });

        $(document).ready(function () {
            $("#name").focus();
        });
    
        </script>
    </body>
</html>
