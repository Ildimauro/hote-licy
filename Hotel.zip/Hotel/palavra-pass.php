<html lang="pt">
    <head>
		<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Hotel Projecto ISI - Recuperação da senha</title>
        <meta name="description" content="Login" />
        <meta name="keywords" content="Login" />
        <meta name="author" content="Hildo Domingos João" />
        
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="bootstrap/css/theme.css" rel="stylesheet">
	<link href="bootstrap/manjolo.css" rel="stylesheet">
    <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>
        <script src="js/modernizr.custom.63321.js"></script>
		<style>
		</style>
    </head>
    <body role="image" background="pics/unnamerrd.png">

<?php

require_once "conexao.php";

$usuario=$_POST['usuario'];

$sql="SELECT * FROM tabela_usuarios WHERE idUsuario='$usuario'";
$resultado=mysqli_query($conectar,$sql);
$dados=mysqli_fetch_array($resultado);

//$id=$_GET['id'];
if(mysqli_num_rows($resultado)>0){
   
    //echo 

     //$pass=MD5($dados['senha']);

     //echo "<br> $pass";
     

?>


<form class="row g-3 needs-validation" method="POST" action="alterar-senha.php?id=<?php echo $dados['idUsuario']; ?>">

<div align="center">
<div class="col-md-12">
<label for="user" class="form-label"><b>Nome do Usuario encontrado</b> </label>
<div class="input-group has-validation">
<p class="clearfix">
                  <input type="text" class="form-control" id="user" value="<?php echo $dados['idUsuario'];?>" name="nome" disabled>
</p>  
                </div>
          </div>
          <br>
          <br>
          <div class="col-md-12">
          <button class="btn btn-primary" type="submit">Alterar a Senha</button>
          </div>
          </div>
          
  <!-- <div class="col-12">
    <button type="submit" class="btn btn-primary">Entrar</button>
  </div> -->

</form>
<?php
}
else{
    print "<script>alert ('usuario não encontrado, por favor inseri um Nome de Usuário válido')</script>";
    require_once "recuperar-senha.php";

}
?>

</body>
</html>
