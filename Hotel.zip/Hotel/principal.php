<?php
session_start();
include_once("seguranca.php");
include_once("conexao.php");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="xigubo">
<meta name="author" content="Hildo Domingos João">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="pics/frontal.jpg" type="image/x-icon">

<title>HOTEL LICY-SOYO</title>
<link href="bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap-responsive.css">
<!-- <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet"> -->
<!-- <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet"> -->
<link type="text/css" href="bootstrap/css/manjolo.css" rel="stylesheet">
<link type="text/css" href="bootstrap/css/side.css" rel="stylesheet">
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="bootstrap/js/manjolo.js"></script>
<link rel="stylesheet" type="text/css" href="bootstrap/css/animate.css">
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript" charset="utf-8" ></script>

<link id="t-colors" href="bootstrap/skins/default.css" rel="stylesheet" />
</head>
<body role="document">
<?php 	require_once("menu.php");
        require_once("P_Menu.php");
		//include_once("rodape.php");
?>
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->

<script src="bootstrap/js/jquery.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="bootstrap/js/ie10-viewport-bug-workaround.js"></script>

</body>
</html>

