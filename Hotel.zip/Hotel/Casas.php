<?php
	include_once("principal.php");

?>

<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript" charset="utf-8" ></script>
<script type="text/javascript">
	$(document).ready(function() {
		$('#myTable').DataTable( {
		"language": {
		"lengthMenu": "Mostrando _MENU_ registros por pagina",
		"zeroRecords": "Nada encontrado - Desculpe",
		"info": "Visualisando _PAGE_ de _PAGES_",
		"infoEmpty": "Sem registros disponiveis",
		"infoFiltered": "(Filtrado de _MAX_ registros totais)"
		}
		} );
		} );
		
</script>

<?php
	if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
	}
?>
<?php
 
if (isset($_POST['buscar'])) {
    $pesquisar = $_POST['PalavraChave'];
    $resultado = mysqli_query($conectar,"select * from alojamento where Tipo LIKE '$pesquisar%' OR `Tipo` LIKE '$pesquisar%'");
    
}else{
	$resultado = mysqli_query($conectar,"SELECT * FROM alojamento ORDER BY 'Tipo'");
	
}



?>
<div class="container-fluid">
<div class="row-fluid">
<div class="col col-lg-H col-md-H col-sm-H haggy">
    <div class="panel panel-default panel-table">
        <div class="panel-heading" >
            
              <p>
              	
                	<div class="divH"><label>Tipos de Casas VIP do Hotel</label></div>
                	<div class="text-right divH ">
                		 <a href="Criar_Casas.php?usuarioId=<?php echo $_SESSION['usuarioId'] ?>"><button type='button' class='text-right btn btn-sm btn-info'><span class="glyphicon glyphicon-plus"></span> </button></a>
                	</div>
                
              </p> 
        </div>	 
        <div class="panel-body">
			

            	
					<!-- <form name="form2" method="post" action="">
						<div class="col-sm-3  form-group" >
							<input type="text" class="input-sm form-control" name="PalavraChave" maxlength="30" size='25' placeholder="Numero do processo ou nome" required="">
				    	</div>
				   		<div class="col-sm-1 col-md-1">
							<button class='btn btn-sm btn-success' name='buscar'><span class="glyphicon glyphicon-search"></span> Pesquisar</button>
				    	</div>
					</form> -->
                

              <div class="col col-xs-12 col-md-12 col-sm-12 col-lg-12">
              		<p>
              			
								<label for="texto">Número dos tipos de Casas: <?php  $num = mysqli_num_rows($resultado);  echo "$num"; ?></label>
              		</p> 
            <div class="row-fluid">
            <div class="table-responsive">
			  
			<form name="form1" method="post" action="">
			   
                <table id="myTable" class="table table-bordered table-striped  table-responsive table-hover">
                  <thead class="btn-primary">
              		<th>Tipo de Cómodo</th>			
					
					<th>Preço / Noite</th>
					
					
					<th >Acções</th>
				  </tr>
				</thead>
				<tbody class="searchable">
				
			<?php
			  
				while($linhas = mysqli_fetch_array($resultado)){
					echo "<tr>";
						
                        echo "<td>".$linhas['Tipo']."</td>";
						
						echo "<td>".number_format($linhas['Preco'],2)." AOA /Noite</td>";
											
						?>
						<input type="hidden" class="form-control" name="idUsuario" value="<?php echo $linhas['idUsuario'];?>">
						
						<td> 
						<a class="hidden" href=''><button  type='button' class='btn btn-sm btn-primary btn'><span class="glyphicon glyphicon-eye-"></span>Reservado</button></a>
						<a class="hidden" href=''><button  type='button' class='btn btn-sm btn-success btn'><span class="glyphicon glyphicon-eye-open"></span>Confirmado</button></a>
						<a class="hidden" href=''><button  type='button' class='btn btn-sm btn-success btn'><span class="glyphicon glyphicon-eye-open"></span>Confirmado</button></a>
						<a href='Casas-editar.php?id=<?php echo $linhas['id']; ?>'><button type='button' class='btn btn-sm btn-warning'><span class="glyphicon glyphicon-edit"></span> Editar</button></a>
						<?php
						if($_SESSION['usuarioNivelAcesso']==1){?>
						<button type="button" name="delete" data-toggle="modal" data-target="#delete" data-whatever="<?php echo $linhas['id']?>" class='btn btn-sm btn-danger btn' ><span class="glyphicon glyphicon-trash"> </span> Eliminar</button>
						</td>
						<?php
					}
					echo "</tr>";
				}
			?>
		</tbody>
	  </table>
	  </form>
	 <button type='button' onclick="Voltar()" class='btn btn-info'><span class="glyphicon glyphicon-arrow-left"></span>Voltar</button>
	<p class="clearfix"></p>
</div>
</div>
</div>
</div>
</div> <!-- /container -->

<!-- Inicio Modal Apagar -->
				<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
				<div class="modal-dialog">
				<div class="modal-content">
				<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
				<h4 class="modal-title custom_align" id="Heading">Eliminar Dados</h4>
				</div>
				<form name="form" method="POST" name="CasaEliminar">
				<div class="modal-body">
				
				
				<input type="hidden" name="id" class="form-control" id="id">
				<div class="alert alert-danger"> <b>NB:</b> Ao eliminar o tipo de casa, estará também mudando os dados do site da Sombra.
					<br>
				 Deseja prosseguir com a eliminação?
				</div>
				
				<div class="modal-footer ">
				<button type="submit" name="CasaEliminar" class="btn btn-success" ><span class="glyphicon glyphicon-trash"></span> Sim</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Não</button>
				 </div></div> </div></div> </form>
				<!-- Fim Modal -->


				<script type="text/javascript">
		$('#delete').on('show.bs.modal', function (event) {
		  var button = $(event.relatedTarget) // Button that triggered the modal
		  var recipient = button.data('whatever') 
		  var modal = $(this)
		  //modal.find('.modal-title').text('Editar Usuario - idUsuario: ' + recipient)
		  modal.find('#id').val(recipient)
		
		  })
	</script>
<?php 
if(isset($_POST['CasaEliminar'] )){
	$id = $_POST["id"];

	$query=mysqli_query($conectar,"DELETE FROM alojamento WHERE id='$id'");
	if ($query) 
					/*$inserir1 = mysqli_query($conectar,"INSERT INTO tabela_usuarios (idUsuario, nome,senha, estado, idNivelAcesso , dataCadastro) VALUES ('$email', '$nome $apelido', '$senha', 'Activo', '2', NOW())");
					if ($inserir1)*/{
					$_SESSION['mensagem'] = "
													
														<div class='alert alert-success' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															Tipo de casa eliminado com sucesso!.
														</div>
												   	";
					//Manda o usuario para a tela de login
					header("Location: Casas.php");
				}else{
					$_SESSION['mensagem'] = "
													
														<div class='alert alert-danger' role='alert'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
															
															Error: ".mysqli_error($conectar)."
														</div> 
												   	";
					header("Location: Casas.php");
				}
}
 ?>
}
<?php
	include_once("rodape.php");
?>