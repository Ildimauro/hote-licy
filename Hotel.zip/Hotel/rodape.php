<footer>
	<div class="navbar navbar-default navbar-fixed-bottom" style="background-color: #ececec;">
	<div class="panel-heading">
		<div align="center" >
			 Todos Direitos Reservados a <b><a href="http://facebook.com/ildmauroNews" target="blank" style="color: #000;">Hotel Licy</a></b>
		</div>
		<div align="center" >
			Desenhado e Concebido por
			<b><a href="http://facebook.com/ildo.domingasjoao" target="blank" style="color: #000;">"Estudades do Instituto do Kitona"</a></b>
			Copyright &copy 2023.
		</div>
	</div>
	</div>
</footer>
