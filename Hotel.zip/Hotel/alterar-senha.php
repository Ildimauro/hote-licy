<html lang="pt">
    <head>
		<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Hotel Projecto ISI - Recuperação da senha</title>
        <meta name="description" content="Login" />
        <meta name="keywords" content="Login" />
        <meta name="author" content="Hildo Domingos João" />
        
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="bootstrap/css/theme.css" rel="stylesheet">
	<link href="bootstrap/manjolo.css" rel="stylesheet">
    <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>
        <script src="js/modernizr.custom.63321.js"></script>
		<style>
		</style>
    </head>
    <body role="image" background="pics/unnamerrd.png">

<?php

require_once "conexao.php";

$id=$_GET['id'];

$sql="SELECT * FROM tabela_usuarios WHERE idUsuario='$id'";
$resultado=mysqli_query($conectar,$sql);
$dados=mysqli_fetch_array($resultado);
?>

<form method="POST" action="actualizar-senha.php" >
    <center>
<font color="blue">
<label><h2>Criar nova Senha</h2></label>
</font>
<br>
<br>
<input Type="hidden" name="id" value="<?php echo $dados['idUsuario'];?>">

<div align="center">
<div class="col-md-12">
    <label for="td" class="form-label"><b> Nova Senha</b></label>
    <div class="input-group has-validation">
<p class="clearfix">
						
						<td><input required name="senha" type="password" autocomplete="off" class="form-control" class="td" size="30" maxlength="25" placeholder=" &#128272;Criar Senha"/>
					</p>
					</div>
</div>


<div class="col-md-12">
    <label for="td" class="form-label"><b>confirmar a senha</b></label>
    <div class="input-group has-validation">
<p class="clearfix">
						
						<td><input required name="conf" type="password" autocomplete="off" class="form-control" class="td" size="30" maxlength="25" placeholder=" &#128272;Confirmar a Senha"/>
					</p>
                    </div>
</div>		
</div>
<button class="btn btn-primary" type="submit">Actualizar Senha</button>
</center>
</form>
