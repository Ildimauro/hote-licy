<?php 
require_once 'dompdf/autoload.inc.php';
include_once("conexao.php");
use Dompdf\Dompdf;

if (isset($_GET['nome'])) {
	$nome=$_GET['nome'];
	$nome=ltrim(rtrim($nome));
	$query = mysqli_query($conectar,"SELECT * FROM reservas WHERE Nome = '$nome'");
	$resultado = mysqli_fetch_assoc($query);
	$tipo=ltrim(rtrim($resultado['Alojamento']));
	$sql = mysqli_query($conectar,"SELECT * FROM rooms WHERE tipo = '$tipo' LIMIT 1");
	$room = mysqli_fetch_assoc($sql);
	$num_dias=strtotime($resultado['CheckOut'])-strtotime($resultado['CheckIn'])-86400;
    $num_dias=date('d',$num_dias);
    if($num_dias>1){ $dias=" dias";} else{ $dias=" dia ";}
      $preco=number_format($room['Preco']*$num_dias, 2);
	
$Cabecalho = '
<html>

<link href="bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet">

<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>

<script src="bootstrap/js/jquery.js"></script>

<body>
<div align="center">
					<p class="clearfix">
						<img src="pics/frontal.JPG" style="height: 50px;">
					</p>
					<h4>HOTEL LICY/SOYO</h4>
					
					<h5>Celular: +244 936 323 003 | +244 946126656 </h5>
					<h5>Endereço:  Email: ildodomingasjoao@gmail.com</h5>
</div>
<h4><label>Dados pessoais</label></h4>

			  <table width="100%" border="0" class="table ">
				  <tr>
				    <td >Nome Completo: '.$nome.'</td>
				    <td >Nome Da Empresa: '.$resultado['empresa'].'</td>
				  </tr>
				  
			  	  <tr>
				  	<td >Celular: '.$resultado['Celular'].'</td>
				  	<td >Email: '.$resultado['email'].'</td>
				  </tr>
				  
				  <tr>
				  	<td colspan="2">
														<h4 class="alert-info text-center" >
														
															<b>Dados da reserva</b>
														</h4>
							  </td>

				  </tr>
				  <tr>
				  	<td >Número da reserva: '.$resultado['id'].'</td>	
				  	<td >Alojamento: '.$resultado['Alojamento'].'</td>				    				    
				  </tr>
				  <tr>
				  	<td >Adultos: '.$resultado['N_Adultos'].'</td>
				  	<td >Crianças: '.$resultado['N_Criancas'].'</td>
				  </tr>
				  <tr>
				  	<td >Data e Hora de CheckIn: '.$resultado['CheckIn'].'</td>
				  	<td >Data e Hora de CheckOut: '.$resultado['CheckOut'].'</td>
				  </tr>
				  <tr>
				  	<td >Total dias: '.$num_dias. $dias.'</td>
				  	<td >Total a pagar: '.$preco.' AOA</td>
				  </tr>
				</table>  
				  <p >&nbsp;</p>
				  <p >&nbsp;</p>
				  <p >&nbsp;</p>
				  <p >&nbsp;</p>
				  
				  <div align="center">
					<p align="center"><h5>Endereço:  Rua da Faculdade-Kitambi-Soyo,Zaire, Angola</h5></p>
					<p align="center">'.$resultado['DataReserva'].'</p>
				  </div>		
</body>
</html>
';

$Doc="Comprovativo da Reserva.pdf";
$dompdf=new Dompdf();
$dompdf->loadHTML($Cabecalho);
//$dompdf->setPaper('A4','landscape');
$dompdf->render();
$dompdf->stream($Doc,array('attachment'=>0));

}




?>