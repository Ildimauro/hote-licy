<?php
require_once '_db.php';

$stmt = $db->prepare("SELECT * FROM reservations WHERE NOT ((end <= :start) OR (start >= :end))");
$stmt->bindParam(':start', $_POST['start']);
$stmt->bindParam(':end', $_POST['end']);
$stmt->execute();
$result = $stmt->fetchAll();

class Event {}
$events = array();

date_default_timezone_set("UTC");
$now = new DateTime("now");
$today = $now->setTime(0, 0, 0);

foreach($result as $row) {
    $e = new Event();
    $e->id = $row['id'];
    $e->text = $row['name']."<br>";
    $e->Celular = $row['Celular'];
    $e->N_Criancas = $row['N_Criancas'];
    $e->N_Adultos = $row['N_Adultos'];
    $e->start = $row['start'];
    $e->email = $row['email'];
    $e->empresa = $row['empresa'];
    $e->end = $row['end'];
    // additional properties
    $e->status = $row['status'];
    $e->paid = number_format($row['valor_pago'], 2);
    $events[] = $e;
    $e->resource = $row['room_id'];
    $e->usuarioAtualizacao = $row['usuarioAtualizacao'];
    $e->usuarioReserva = $row['usuarioReserva'];
    $e->status = $row['status'];
    $e->bubbleHtml = "<br><div class='alert alert-info' role='alert'>Detalhes da reserva:</div> <b>Empresa:</b> ".$e->empresa."<br><b>Nome:</b> ".$e->text."<b>Celular:</b> ".$e->Celular."<br><b>Email:</b> ".$e->email."<br><b>Adultos:</b> ".$e->N_Adultos."<br><b>Crianças:</b> ".$e->N_Criancas."<br><b>CheckIn:</b> ".$e->start."<br><b>CheckOut:</b> ".$e->end."<br><b>Valor Pago:</b> ".$e->paid."<br><b>Autor da reserva:</b> ".$e->usuarioReserva."<br><b>Editor:</b> ".$e->usuarioAtualizacao."<br><b>Estado:</b> ".$e->status;
    
    

    /*
        int paid = Convert.ToInt32(e.DataItem["ReservationPaid"]);
        string paidColor = "#aaaaaa";

        e.Areas.Add(new Area().Bottom(10).Right(4).Html("<div style='color:" + paidColor + "; font-size: 8pt;'>Paid: " + paid + "%</div>").Visibility(AreaVisibility.Visible));
        e.Areas.Add(new Area().Left(4).Bottom(8).Right(4).Height(2).Html("<div style='background-color:" + paidColor + "; height: 100%; width:" + paid + "%'></div>").Visibility(AreaVisibility.Visible));  
     * */
}

header('Content-Type: application/json');
echo json_encode($events);

?>
