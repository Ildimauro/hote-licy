<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="pt">
    <head>
		<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="shortcut icon" href="pics/frontal.jpg" type="image/x-icon"> 
        <title>Login - Hotel Licy</title>
        <meta name="description" content="Login" />
        <meta name="keywords" content="Login" />
        <meta name="author" content="Hildo Domingos João" />
          <!-- CSS Materalize -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="start/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="start/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <!--fim-->
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="bootstrap/css/theme.css" rel="stylesheet">
	<link href="bootstrap/manjolo.css" rel="stylesheet">
    <script src="bootstrap/js/ie-emulation-modes-warning.js"></script>
        <script src="js/modernizr.custom.63321.js"></script>
		<style>
		</style>
    </head>
    <body role="image" background="pics/frontal.JPG">
        <div class="container">
			
  
   <!-- coluna de Espacamento  a esquerda-->
   
   <a href="../index.html"><div align="center"><h2><font color="blue">Ir ao inicio</font></h2></div></a>

        <div class="col-xs-12  col-lg-4 col-lg-offset-4 col-md-4 col-md-offset-4  col-sm-6 col-sm-offset-3" >
			<br>
			<section class="main"> 
				<form class="form-2" method="post" action="valida-login.php" >
				 	<div class="panel panel-table">
				 		<p class="clearfix">	
							<div  class="panel-primary panel-heading text-center" ><H2 class="panel-title"><label>Hotel LICY/SOYO</label></H2>
						</p>

					</div>
					<div class="panel-body"> 
					<div align="center">
					<p class="clearfix">
						
					</p>
					</div>
					<p class="clearfix" style="color: red">
					<?php
                        if(isset($_SESSION['loginErro'])){
                            echo $_SESSION['loginErro'];
                            unset($_SESSION['loginErro']);
                        }
                    ?>
                   
                    </p>
					<p class="clearfix">
						
						<input required autofocus autocomplete="off" name="usuario" type="imputuser" class="form-control" class="td" size="30" maxlength="25" id="username" placeholder=" &#128272;Usuario"/>
					</p>
					
					<p class="clearfix">
						
						<td><input name="senha" type="password" autocomplete="off" class="form-control" class="td" size="30" maxlength="25" placeholder=" &#128272;Senha"/>
					</p>
					
					<br>
					<p class="clearfix">
					<div align="center">
						<input class="btn btn-lg btn-primary " class="st" id="bt" type="submit" name="Submit" value="Entrar" />
						</div>
					</p>
					<form class="form-2" method="post" action="site.php" >
					<a href="site.php"><b><div align="center">Criar Conta</div></b></a>

					<div align="center"><b>esqueceu a senha?</b></div>
						<a href="recuperar-senha.php"><div align="center">Recupera Aqui</div></a>
					
					</div></form>
				</form>​​
			</section>
			</div>
			</div>
			</div>
        </div>
		<footer class="light-blue lighten-1">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="black-text">Hotel Licy-Soyo</h5>
          <p class="grey-text text-lighten-4">Uma equipe que trabalha desde 2016, 
            mantendo os nossos clientes seguros e bem acomodados. Solicite já os nossos
          serviços, estamos aberto 24/24h
          </p>


        </div>
        <div class="col l3 s12">
          <h5 class="black-text">Actividades</h5>
          <ul>
            <li><a class="white-text" href="../hotel/index.php">Fazer Reserva</a></li>
            <li><a class="white-text" href="../start/galeria.php">Galeria</a></li>
            <li><a class="white-text" href="../hotel/Alojamentos.php">Quartos</a></li>
            <li><a class="white-text" href="#!">Lazer</a></li>
          </ul>
        </div>
        <div class="col l3 s12">
          <h5 class="black-text">Conectar-se</h5>
          <ul>
            <li><a class="white-text" href="../hotel/index.php">Entrar</a></li>
            <li><a class="white-text" href="../hotel/site.php">Criar conta</a></li>
            <li><a class="white-text" href="#!">Contactos</a></li>
            <li><a class="white-text" href="#!">Nosso Facebook</a></li>
            
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
      Todos os direitos Reservado, Criado por: <a class="orange-text text-lighten-3" href="#">Grupo nº03 do Instituto do Kitona/Soyo</a>
      </div>
    </div>
  </footer>

    </body>
</html>