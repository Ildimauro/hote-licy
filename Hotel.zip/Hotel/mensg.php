 <?php
	include_once("principal.php");

?>
<?php
				if(isset($_SESSION['mensagem'])){
					echo $_SESSION['mensagem'];
					unset($_SESSION['mensagem']);
				}
			?>
<div class="container-fluid">
<div class="row-fluid">
<div class="col col-lg-H col-md-H col-sm-H haggy">
	
    <div class="panel panel-default panel-table">
        <div class="panel-heading" >
			<p> 	
	            <div class="divH"><label>mensagem</label></div>
	        </p> 
		</div>

       	<div class="panel-body">
          <form class="form-horizontal" name="mensagem" method="POST" action="conf-mensg.php">
		  <div class="col-sm-4">
				  Nome
				<input type="text" class="input-sm form-control" name="nome" maxlength="50" placeholder="Digite o seu nome aqui" required="">
				</div>	
				<div class="col-sm-4">
				  Telefone
				<input type="text" class="input-sm form-control" name="celular" maxlength="50" placeholder="Digite o contacto aqui" required="">
				</div>	

		  <div class="col-sm-12">
			  <div class="form-group">
						
			  <div class="col-sm-8">
				Assunto:
				  <input type="text" class="input-sm form-control" name="assunto" maxlength="50" placeholder="Digite o assunto aqui" required="">
			</div>	
			  </div>
			</div>
          <div class="col-sm-12">
			  <div class="form-group">
			  
			  <div class="col-sm-8">
				Mensagem:
				  <textarea name="texto" rows="5" maxlength="1000" class="input-sm form-control" placeholder="Digite a sua mensagem aqui" required=""></textarea >
				</div>	
				
			  </div>
			</div>
          	
				<div class="col-sm-12">
			  <div class="form-group">
				<div class="col-sm-6 col col-xs-6 text-left">
				  <button type='button' onclick="Voltar()" class='btn  btn-info'><span class="glyphicon glyphicon-remove"></span>Cancelar</button>
				</div>
				<div class="col-sm-2 col col-xs-6 text-right"> 
				  <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-ok"></span>Enviar</button>
				</div>
				
				</div>
			  </div>
			</form>
        </div>
		</div>
 </div>
 </div>
 </div>
    
    