<?php
include_once("principal.php");

$idUsuario 				= $_POST["idUsuario"];
$senha 				= md5($_POST['senha']);
$nova_senha 		= md5(ltrim(rtrim($_POST['nova_senha'])));

$sql= mysqli_query($conectar,"SELECT * FROM tabela_usuarios WHERE idUsuario='$idUsuario' AND senha='$senha'");
if(mysqli_fetch_assoc($sql)!=""){

	$query = mysqli_query($conectar,"UPDATE `tabela_usuarios` SET `senha` = '$nova_senha', dataModificacao = NOW() WHERE `tabela_usuarios`.`idUsuario` ='$idUsuario'");
	if ($query) {
		$_SESSION['mensagem'] = "
													<div class='alert alert-success' role='alert'> 
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														Senha actualizado com sucesso
													</div>";
	} else {
		$_SESSION['mensagem'] = "
													<div class='alert alert-danger' role='alert'> 
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														Error:".mysqli_error($conectar)."
													</div>";
	}
}else{
		$_SESSION['mensagem'] = "
													<div class='alert alert-danger' role='alert'> 
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														A senha antiga esta incorrecta. Por favor contactar o administrador caso tenha esquecido a sua senha.
													</div>";
}
header("Location: senha-administrador.php");

?>
