<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Novo Cómodo</title>
    	<link type="text/css" rel="stylesheet" href="media/layout.css" />    
        <script src="js/jquery/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="js/daypilot/daypilot-all.min.js" type="text/javascript"></script>
    </head>
    <body>
        <?php
            // check the input
            //is_numeric($_GET['id']) or die("invalid URL");
            
            require_once '_db.php';
            
            $rooms = $db->query('SELECT * FROM rooms');
        ?>
        <form id="f" style="padding:20px;">
            <h1>Novo Cómodo</h1>
            <div>Nome: </div>
            <div><input type="text" id="name" class="input-sm form-control" name="name" style="width: 75%;" value="" /></div>
            <div>Tipo:</div>
            <div>
                <select id="capacity" class="input-sm form-control" name="capacity" style="width: 75%;">
                    <option value='1'>Standard</option>
                    <option value='2'>Duplo</option>
                    <option value='4'>Casa vip</option>
                </select>
            </div>
            
            <div><input type="numer" min="1" max="4" id="Preco" class="input-sm form-control" name="Preco" style="width: 75%;" value="" /></div>
            <div class="space"><input type="submit" class="btn btn-primary" value="Save" /> <a href="javascript:close();">Cancelar</a></div>
        </form>
        
        <script type="text/javascript">
        function close(result) {
            DayPilot.Modal.close(result);
        }

        $("#f").submit(function () {
            var f = $("#f");
            $.post("backend_room_create.php", f.serialize(), function (result) {
                close(eval(result));
            });
            return false;
        });

        $(document).ready(function () {
            $("#name").focus();
        });
    
        </script>
    </body>
</html>
