 <?php
	include_once("principal.php");
?>
<?php
				if(isset($_SESSION['mensagem'])){
					echo $_SESSION['mensagem'];
					unset($_SESSION['mensagem']);
				}
			?>
			
<div class="container-fluid">
<div class="row-fluid">
<div class="col col-lg-H col-md-H col-sm-H haggy">
	
    <div class="panel panel-default panel-table">
        <div class="panel-heading" >
			   
			<p>	              	
	            <div class="divH"><label>Nova Reserva</label></div>  
	        </p> 
		</div>
		<div class="panel-body">
          <form class="form-horizontal" name="Reserva" method="POST" >
   				<div class="col-sm-4">
                Empresa:
                    <input type="text" class="input-sm form-control" name="empresa" placeholder="Opcional">
                </div>
		  
				<div class="col-sm-4">
				Nome:
				  <input type="text" class="input-sm form-control" name="Nome" maxlength="40" placeholder="Nome Completo" required>
				</div>
				<div class="col-sm-4">
				E-mail:
				  <input type="email" class="input-sm form-control" name="email" maxlength="50" placeholder="E-mail" >
				</div>
			  	<div class="col-sm-4">
				Contacto:
				  <input type="text" class="input-sm form-control"  name="Celular" maxlength="9" placeholder="Contacto" required>
				</div>
				
			
				<div class="col-sm-4">
					Número de Adultos:
					<select name="Adultos" id="" required class="input-sm form-control">
						<option value="">Seleccione</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                    </select>
				</div>
			  	<div class="col-sm-4">
					Número de Crianças:
					<select name="Criancas" id=""  class="input-sm form-control">
						<option value=""></option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                    </select>
				</div>
				
					<div class="col-sm-2">
						CheckIn:
						  <input type="date" class="input-sm form-control" min="<?php echo date('Y-m-d') ?>" name="CheckInDate"  required>
					</div>
					<div class="col-sm-2">
							<br>
						  <input type="time" class="input-sm form-control" name="CheckInTime" >
					</div>
				
				  	<div class="col-sm-2">
						CheckOut:
						<input type="date" class="input-sm form-control" name="CheckOutDate"  min="<?php echo date('Y-m-d',strtotime('+1 days')) ?>"  required>
						
					</div>
					<div class="col-sm-2">
						<br>
						<input type="time" class="input-sm form-control" name="CheckOutTime" >
					</div>
					<div class="col-sm-4">
					Alojamento:
					<select class="input-sm form-control" name="Alojamento" required>
				  		<option value="">Selecione aqui</option>
				  		<?php  
				  		$resultado = mysqli_query($conectar,"SELECT * FROM alojamento ORDER BY 'Tipo'");
				  		while($linhas = mysqli_fetch_array($resultado))
	                        echo "<option value=".$linhas['camas'].">".$linhas['Tipo']."</option>";
                        ?>
					</select>
				
			  		</div>
			
         		<div class="row-fluid">
         			<p >&nbsp;</p>
				<div class="col-sm-6 col-xs-6 text-left">
				  <button type='button' onclick="Voltar()" class='btn  btn-info '><span class="glyphicon glyphicon-remove"></span>Voltar</button>
				</div>
				<div class="col-sm-6 col-xs-6 text-right"> 
                  <button type="submit" name="Reserva" class="btn btn-success "><span class="glyphicon glyphicon-floppy-disk"></span> Submeter</button>
				</div></div>
				</form>

			</div>
</div>
</div>
</div>

    
    <?php 

if(isset ($_POST['Reserva'])){
    
    
   $nome = $_POST['Nome'].' '.$_POST['Apelido'];
 	$nome=ltrim(rtrim($nome));
    $email = $_POST['email'];
    $Celular = $_POST['Celular'];
    $N_Adultos = $_POST['Adultos'];
    $N_Criancas = $_POST['Criancas'];
    $CheckIn = $_POST['CheckInDate'].' '.$_POST['CheckInTime'];
    $CheckOut = $_POST['CheckOutDate'].' '.$_POST['CheckOutTime'];
    $Alojamento = $_POST['Alojamento'];
    $query = mysqli_query($conectar,"SELECT * FROM rooms WHERE capacity = '$Alojamento' LIMIT 1");
    $room = mysqli_fetch_assoc($query);
    $tipo = $room['tipo'];
    $empresa = $_POST['empresa'];
    $DataCheckIn=$CheckIn = $_POST['CheckInDate'];
    $DataCheckOut = $_POST['CheckOutDate'];
    /*$num_dias=strtotime($CheckOut)-strtotime($CheckIn)-86400;
    $num_dias=date('d',$num_dias);
    if($num_dias>1) $dias=" dias"; else $dias=" dia ";
      $preco=number_format($room['Preco']*$num_dias, 2);*/
    if(strtotime($DataCheckIn)<strtotime($DataCheckOut)){
        //Inserindo os dados do formulario usercadastrar na tabela usuarios
         $inserir = mysqli_query($conectar,"INSERT INTO reservas (`CheckIn`, `CheckOut`, `Alojamento`, `Nome`, `empresa`,`Celular`, `email`, `N_Adultos`, `N_Criancas`,`DataReserva`) VALUES ('$CheckIn','$CheckOut','$tipo', '$nome', '$empresa','$Celular', '$email', '$N_Adultos', '$N_Criancas', NOW())");
          
         
                
        if ($inserir) {
          $sql1 = mysqli_query($conectar, "INSERT INTO `notificacoes` (`Titulo`, `Texto`, `idNivel_acesso`, `Data`, `Estado`) VALUES ('Nova Reserva', 'Nova reserva no nome de <b>$nome.</b>', 2, NOW(), '1')");
          /*$inserir1 = mysqli_query($conectar,"INSERT INTO tabela_usuarios (idUsuario, nome,senha, estado, idNivelAcesso , dataCadastro) VALUES ('$email', '$nome $apelido', '$senha', 'Activo', '2', NOW())");
          if ($inserir1)*/
          $_SESSION['mensagem'] = "
                          
                            <div class='alert alert-success' role='alert'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
                             A sua Reserva foi feita com sucesso!
                             <a href='File.php?nome= $nome'><button type='button' class='text-right btn btn-sm btn-info'><span class='glyphicon glyphicon-print'></span> Imprimir comprovativo</button></a>
                            </div>
                            ";
          header("Location: Reservas.php");
        }else{
          $Error=mysqli_error($conectar);
          if(mysqli_error($conectar)=="Duplicate entry '$nome' for key 'Nome'") 
            $Error="Já existe uma reserva com este nome. Por favor contactar a Hotel Projecto ISI para mais informações.";
          $_SESSION['mensagem'] = "
                          
                            <div class='alert alert-danger' role='alert'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
                              
                              Error: ".$Error."
                            </div> 
                            ";
          header("Location: Criar_Reserva.php");
        }
       
    }else{
      $_SESSION['mensagem'] = "
                          
                            <div class='alert alert-danger' role='alert'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a> 
                              A data do CheckOutDate nao pode ser inferior e nem igual ao do CheckIn.
                            </div> 
                            ";
          header("Location: Criar_Reserva.php");
    }
    
}
?>
    
<?php
	include_once("rodape.php");
?>