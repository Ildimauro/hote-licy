<?php
	include_once("principal.php");

?>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript" charset="utf-8" ></script>

<script type="text/javascript">
	$(document).ready(function() {
		$('#myTable').DataTable( {
		"language": {
		"lengthMenu": "Mostrando _MENU_ registros por pagina",
		"zeroRecords": "Nada encontrado - Desculpe",
		"info": "Visualisando _PAGE_ de _PAGES_",
		"infoEmpty": "Sem registros disponiveis",
		"infoFiltered": "(Filtrado de _MAX_ registros totais)"
		}
		} );
		} );
		
</script>

<?php
	if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
	}
?>
<?php
 
if (isset($_POST['buscar'])) {
    $pesquisar = $_POST['PalavraChave'];
    $resultado = mysqli_query($conectar,"select * from reservas where Nome LIKE '$pesquisar%' OR `Apelido` LIKE '$pesquisar%'");
    
}else{
	$resultado = mysqli_query($conectar,"SELECT * FROM reservas ORDER BY 'CheckIn'");
	
}



?>
<div class="container-fluid">
<div class="row-fluid">
<div class="col col-lg-H col-md-H col-sm-H haggy">
    <div class="panel panel-default panel-table">
        <div class="panel-heading" >
            
              <p>
              	
                	<div class="divH"><label>Reservas</label></div>
                	<div class="text-right divH">
                		 <a href="Criar_Reserva.php?usuarioId=<?php echo $_SESSION['usuarioId'] ?>"><button type='button' class='text-right btn btn-sm btn-info'><span class="glyphicon glyphicon-plus"></span> </button></a>
                	</div>
                
              </p> 
        </div>	 
        <div class="panel-body">
			

            	
					<!-- <form name="form2" method="post" action="">
						<div class="col-sm-3  form-group" >
							<input type="text" class="input-sm form-control" name="PalavraChave" maxlength="30" size='25' placeholder="Numero do processo ou nome" required="">
				    	</div>
				   		<div class="col-sm-1 col-md-1">
							<button class='btn btn-sm btn-success' name='buscar'><span class="glyphicon glyphicon-search"></span> Pesquisar</button>
				    	</div>
					</form> -->
                

              <div class="col col-xs-12 col-md-12 col-sm-12 col-lg-12">
              		<p>
              			
								<label for="texto">Número de reservas: <?php  $num = mysqli_num_rows($resultado);  echo "$num"; ?></label>
              		</p> 
            <div class="row-fluid">
            <div class="table-responsive">
			  
			<form name="form1" method="post" action="">
			   
                <table id="myTable" class="table table-bordered table-striped  table-responsive table-hover">
                  <thead class="btn-primary">
              		<th>Número da reserva</th>	
              		<th>Alojamento</th>
              		<th>Empresa</th>			
					<th>Nome</th>
					<th>E-mail</th>
					<th>Contacto</th>
					<th>Adultos</th>
					<th>Crianças</th>
					<th>CheckIn</th>
					<th>CheckOut</th>
					<th>Tempo dias</th>
					<th >Acções</th>
				  </tr>
				</thead>
				<tbody class="searchable">
				
			<?php
			  
				while($linhas = mysqli_fetch_array($resultado)){
					$num_dias=strtotime($linhas['CheckOut'])-strtotime($linhas['CheckIn'])-86400;
				    $num_dias=date('d',$num_dias);
				    if($num_dias>1) $dias=" dias"; else $dias=" dia ";
				     /* $preco=number_format($room['Preco']*$num_dias, 2);*/
					echo "<tr>";
						echo "<td>".$linhas['id']."</td>";
                        echo "<td>".$linhas['Alojamento']."</td>";
                        echo "<td>".$linhas['empresa']."</td>";
						echo "<td>".$linhas['Nome']."</td>";
                        echo "<td>".$linhas['email']."</td>";
						echo "<td>".$linhas['Celular']."</td>";
						echo "<td>".$linhas['N_Adultos']."</td>";
						echo "<td>".$linhas['N_Criancas']."</td>";
						echo "<td>".$linhas['CheckIn']."</td>";
						echo "<td>".$linhas['CheckOut']."</td>";
						echo "<td>".$num_dias.$dias."</td>"					
						?>
						<input type="hidden" class="form-control" name="idUsuario" value="<?php echo $linhas['idUsuario'];?>">
						
						<td> 
						 <button type="button" name="Marcar" data-toggle="modal" data-target="#Marcar" data-whatever="<?php echo $linhas['id']?>" class='btn btn-sm btn-primary btn' ><span class="glyphicon glyphicon-ok-sign"> </span> Marcar</button>



				
						
						
						<?php
					echo "</tr>";
				}
			?>
			
		</tbody>
	  </table>
	  </form>
	 <button type='button' onclick="Voltar()" class='btn btn-info'><span class="glyphicon glyphicon-arrow-left"></span>Voltar</button>
	<p class="clearfix"></p>
</div>
</div>
</div>
</div>
</div> <!-- /container -->


<!-- Inicio Modal Apagar -->
		<div class="modal fade" id="Marcar" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<form name="form1" method="POST" action="backend_create.php">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
							<h4 class="modal-title custom_align" id="Heading">Marco da reserva online</h4>
						</div>
						<script type="text/javascript">
							var id =$("#id").value();
						</script>
						<?php
							$query=mysqli_query($conectar,"SELECT * FROM rooms ORDER BY LENGTH(id), id");
		                ?>
						<div class="modal-body">
							<input type="hidden" name="id" id="id" class="form-control">

							<label>Cómodo</label>
							<select class="input sm form-control" name="room" required="">
								<option></option>
							<?php 
				                while($linhas=mysqli_fetch_array($query)){ 
				                    echo "<option value = '".$linhas['id']."'>".$linhas['name']."</option>";
				                }
				            ?>
							</select>
						</div>
						<div class="modal-footer ">
							<button type="submit" class="btn btn-success" name="reservaOnline" ><span class="glyphicon glyphicon-ok-sign"></span> Sim</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Não</button>
						</div>
					
				</div> 
			</div>
		</div> </form>
				<!-- Fim Modal -->


				<script type="text/javascript">
				$('#Marcar').on('show.bs.modal', function (event) {
				  var button = $(event.relatedTarget) // Button that triggered the modal
				  var recipient = button.data('whatever') 
				  var modal = $(this)
				  //modal.find('.modal-title').text('Editar Usuario - idUsuario: ' + recipient)
				  modal.find('#id').val(recipient)
				
				  })
	</script>

<?php
	include_once("rodape.php");
?>