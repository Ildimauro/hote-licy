<?php
include_once("principal.php");

    
?>

<?php
	if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
	}
?>

<?php 
    if(isset($_POST['filtroMes'])){
       $mes=$_POST['mes']."-00";
       $reservas= mysqli_query($conectar,"SELECT * FROM reservations WHERE month(start)=month('$mes')");
       $ocupacoes= mysqli_query($conectar,"SELECT * FROM reservations WHERE status='Confirmada' AND month(start)=month('$mes')");
       $rendimento= mysqli_query($conectar,"SELECT SUM(valor_pago) FROM `reservations` WHERE status='Confirmada' AND month(start)=month('$mes')");   
       $row = mysqli_fetch_row($rendimento);
       $total= $row[0];
       
    }else if(isset($_POST['filtroDia'])){
       $dia=$_POST['dia'];
       $reservas= mysqli_query($conectar,"SELECT * FROM reservations WHERE '$dia' BETWEEN start AND end");
       $ocupacoes= mysqli_query($conectar,"SELECT * FROM reservations WHERE status='Confirmada' AND '$dia' BETWEEN start AND end");
       $rendimento= mysqli_query($conectar,"SELECT SUM(valor_pago) FROM `reservations` WHERE status='Confirmada' AND '$dia' BETWEEN start AND end");   
       $row = mysqli_fetch_row($rendimento);
       $total= $row[0];
       
    }elseif(isset($_POST['filtroData'])){
       $start=$_POST['start'];
       $end=$_POST['end'];
       $reservas= mysqli_query($conectar,"SELECT * FROM reservations WHERE start BETWEEN '$start' AND '$end' OR end BETWEEN '$start' AND '$end'");
       $ocupacoes= mysqli_query($conectar,"SELECT * FROM reservations WHERE status='Confirmada' AND start BETWEEN '$start' AND '$end' OR end BETWEEN '$start' AND '$end'");
       $rendimento= mysqli_query($conectar,"SELECT SUM(valor_pago) FROM `reservations` WHERE status='Confirmada' AND start BETWEEN '$start' AND '$end' OR end BETWEEN '$start' AND '$end'");   
       $row = mysqli_fetch_row($rendimento);
       $total= $row[0];
       
    }else {
       $reservas= mysqli_query($conectar,"SELECT * FROM reservations");
       $ocupacoes= mysqli_query($conectar,"SELECT * FROM reservations WHERE status='Confirmada'");
       $rendimento= mysqli_query($conectar,"SELECT SUM(valor_pago) FROM `reservations` WHERE status='Confirmada'");   
       $row = mysqli_fetch_row($rendimento);
       $total= $row[0];
    }

    
?>

<div class="container-fluid" >
   <p><h1 align="center" class=" alert alert-info col">Seja Bem Vindo <br>Sr(a) <?php echo $_SESSION['usuarioNome']; ?></h1></p>
	<div class="row-fluid">
	<div class="col col-lg-H col-md-H col-sm-H haggy">
            
			<div class="col-lg-4">
            <div class="panel panel-danger alert alert-info ">
      				<h1 align="center" class="text-danger">Reservas</h1>
              <?php
              if($_SESSION['usuarioNivelAcesso']==1){
              ?>
  					  <center>
      				 <strong class="text-danger">Total: <?php echo mysqli_num_rows($reservas); ?></strong> <br>
      				</center>
              <?php
              }
              ?>
					  </div>
      </div>
      <div class="col-lg-4">
               	<div class="panel panel-success alert alert-info">
    				<h1 align="center" class="text-success">Ocupações</h1>
					
    				
					 <center>
    				 <strong class="text-success">Total: <?php echo mysqli_num_rows($ocupacoes); ?></strong> <br>
    				 
    				 </center>
					 
 				</div>
      </div>
      <div class="col-lg-4">
               	<div class="panel panel-primary alert alert-info">
    				<h1 align="center" class="text-primary">Rendimento</h1>
            <?php
              if($_SESSION['usuarioNivelAcesso']==1){
              ?>
    				<center>
    				 <strong class="text-primary">Total: <?php echo number_format($total,2)." AOA"; ?></strong> <br>
    				 
    				 </center>
             <?php
              }
              ?>
 				</div>
      </div>
            <h2 class="text-center"> <b>Filtros</b></h2>
              <form name="form2" method="POST" class="" style="z-index: 0;" action="">
                  <div class="col-lg-2 col-xs-12" style="z-index: 0;">
                    <p><b>Dia</b></p>
                    <div class="input-group">

                      <input type="date" class="input-sm form-control" name="dia" value="<?php echo $_POST['dia'] ?>">
                      <span class="input-group-btn">
                        <button name="filtroDia" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-filter"></span> Filtrar</button>
                      </span>
                    </div>
                  </div>   
              </form>
              <div class="col-lg-2"></div>
             <form name="form2" method="POST" class="" style="z-index: 0;" action="">

                  <div class="col-lg-4 col-xs-12" style="z-index: 0;">
                    <p class="text-center"><b>Data</b> DD-MM-AAAA até <b>Data</b> DD-MM-AAAA</p>
                    <div class="input-group">

                      <input type="date" class="input-sm form-control" name="start" value="<?php echo $_POST['start'] ?>">
                      <span class="input-group-btn">
                        
                      </span>

                      <input type="date" class="input-sm form-control" name="end" value="<?php echo $_POST['end'] ?>">
                      <span class="input-group-btn">
                        <button name="filtroData" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-filter"></span> Filtrar</button>
                      </span>
                    </div>
                  </div>   
              </form>
              <div class="col-lg-2"></div>
             	<form name="form1" method="POST" class="" action="">
             		  <div class="col-lg-4 col-xs-12">
                    <p><b>MÊS</b></p>
                    <div class="input-group">
                      <input type="month" class="input-sm form-control" name="mes" value="<?php echo $_POST['mes'] ?>">
                      <span class="input-group-btn">
                        <button name="filtroMes" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-filter"></span> Filtrar</button>
                      </span>
                    </div>
                  </div>   
              </form>
              
    </div>
	</div>
</div>

<p class="visible-sm">&nbsp;</p>
              <p class="visible-sm">&nbsp;</p>
              <p class="visible-sm">&nbsp;</p>
              <p class="visible-sm">&nbsp;</p>
           
<?php
	include_once("rodape.php");
?>


