<?php
//session_start();
include_once("principal.php");

$idUsuario 			= $_POST["idUsuario"];
$nome 				= $_POST["nome"];
$email 				= $_POST["email"];
$usuario 			= $_POST["usuario"];
$senha 				= $_POST['senha'];
$confirmacao 		= $_POST['confirmacao'];
$nivel_de_acesso 	= $_POST["nivel_de_acesso"];


	$senha = md5($_POST["senha"]);
	$confirmacao = md5($_POST["confirmacao"]);
	
if($senha == $confirmacao){
	$query = mysqli_query($conectar,"UPDATE login set usuario ='$usuario' WHERE usuario='$idUsuario'");
	$query = mysqli_query($conectar,"UPDATE reservations set usuarioReserva ='$usuario' WHERE usuarioReserva='$idUsuario'");
	$query = mysqli_query($conectar,"UPDATE reservations set usuarioAtualizacao='$usuario' WHERE usuarioAtualizacao='$idUsuario'");
	$query = mysqli_query($conectar,"UPDATE tabela_usuarios set nome ='$nome', idUsuario ='$usuario', senha = '$senha', idNivelAcesso = '$nivel_de_acesso', dataModificacao = NOW() WHERE idUsuario='$idUsuario'");
	if($query){
		$_SESSION['mensagem'] = "
														<div class='alert alert-success' role='alert'> 
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
															Usuário <strong> $nome</strong> editado com sucesso
														</div>";
		
			//Manda o usuario para a tela de notificacao
			header("Location: listarUsuarios.php");
	}else{
	
		$_SESSION['mensagem'] = "
												
													<div class='alert alert-danger' role='alert'> 
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														Erro:".mysqli_error($conectar)."
													</div>";
	
		//Manda o usuario para a tela de editar usuario
		header("Location: Usuario-editar.php?idUsuario=$idUsuario");
	}
}else{
	$_SESSION['mensagem'] = "
													<div class='alert alert-danger' role='alert'> 
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														As senhas do campo <strong>Senha</strong> e <strong>Confirmar a Senha</strong> não coinscidem!
													</div>";
	
		//Manda o usuario para a tela de editar usuario
		header("Location: Usuario-editar.php?idUsuario=$idUsuario");
}
?>
