<!-- Inicio Modal Ver Modal -->
        <div class="modal fade" id="exp" tabindex="-1" role="dialog" aria-labelledby="edit" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header ">
                  <button type="submit" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
                  <h4 class="modal-title custom_align " ><span class="glyphicon glyphicon-bell"></span> Nova dica</h4>
              </div>
                <form name="form" method="POST" action="Usuario-processa-apagarEstudante.php">
              <div class="modal-body">
        
              </div>
              <div class="modal-footer ">
                  <button type="button"  data-dismiss="modal" aria-hidden="true" class="btn btn-primary" ><span class="glyphicon glyphicon-remove"></span> Fechar</button>
        
                </form>
              </div></div> </div></div> 
        <!-- Fim Modal -->